import { create } from 'zustand';

export interface PlacedFurniture {
  id: string;
  furnitureId: string;
  name: string;
  emoji: string;
  x: number;
  y: number;
  rotation: number;
  scale: number;
  color: string;
  colors?: string[];
}

export interface SavedDesign {
  id: string;
  name: string;
  roomType: string;
  thumbnail: string;
  createdAt: string;
  items: PlacedFurniture[];
}

interface DesignState {
  currentItems: PlacedFurniture[];
  savedDesigns: SavedDesign[];
  selectedItemId: string | null;
  arSettings: {
    showGrid: boolean;
    snapToGrid: boolean;
    measurementUnit: 'cm' | 'inches';
  };

  addItem: (item: PlacedFurniture) => void;
  updateItem: (id: string, updates: Partial<PlacedFurniture>) => void;
  removeItem: (id: string) => void;
  selectItem: (id: string | null) => void;
  clearCurrentItems: () => void;

  saveDesign: (name: string, roomType: string) => void;
  deleteDesign: (id: string) => void;
  renameDesign: (id: string, newName: string) => void;
  loadDesign: (id: string) => void;

  updateArSettings: (settings: Partial<DesignState['arSettings']>) => void;
  loadSavedDesigns: () => void;
}

export const useDesignStore = create<DesignState>((set, get) => ({
  currentItems: [],
  savedDesigns: [],
  selectedItemId: null,
  arSettings: {
    showGrid: true,
    snapToGrid: false,
    measurementUnit: 'cm',
  },

  addItem: (item) => 
    set((state) => ({ currentItems: [...state.currentItems, item] })),

  updateItem: (id, updates) =>
    set((state) => ({
      currentItems: state.currentItems.map((item) =>
        item.id === id ? { ...item, ...updates } : item
      ),
    })),

  removeItem: (id) =>
    set((state) => ({
      currentItems: state.currentItems.filter((item) => item.id !== id),
      selectedItemId: state.selectedItemId === id ? null : state.selectedItemId,
    })),

  selectItem: (id) => set({ selectedItemId: id }),

  clearCurrentItems: () => set({ currentItems: [], selectedItemId: null }),

  saveDesign: (name, roomType) => {
    const design: SavedDesign = {
      id: crypto.randomUUID(),
      name,
      roomType,
      thumbnail: '',
      createdAt: new Date().toISOString(),
      items: [...get().currentItems],
    };
    const updated = [design, ...get().savedDesigns];
    localStorage.setItem('designar_saved_designs', JSON.stringify(updated));
    set({ savedDesigns: updated });
  },

  deleteDesign: (id) => {
    const updated = get().savedDesigns.filter((d) => d.id !== id);
    localStorage.setItem('designar_saved_designs', JSON.stringify(updated));
    set({ savedDesigns: updated });
  },

  renameDesign: (id, newName) => {
    const updated = get().savedDesigns.map((d) =>
      d.id === id ? { ...d, name: newName } : d
    );
    localStorage.setItem('designar_saved_designs', JSON.stringify(updated));
    set({ savedDesigns: updated });
  },

  loadDesign: (id) => {
    const design = get().savedDesigns.find((d) => d.id === id);
    if (design) {
      set({ currentItems: [...design.items], selectedItemId: null });
    }
  },

  updateArSettings: (settings) => {
    const newSettings = { ...get().arSettings, ...settings };
    localStorage.setItem('designar_ar_settings', JSON.stringify(newSettings));
    set({ arSettings: newSettings });
  },

  loadSavedDesigns: () => {
    const stored = localStorage.getItem('designar_saved_designs');
    if (stored) {
      set({ savedDesigns: JSON.parse(stored) as SavedDesign[] });
    }
    const storedSettings = localStorage.getItem('designar_ar_settings');
    if (storedSettings) {
      set({ arSettings: JSON.parse(storedSettings) as DesignState['arSettings'] });
    }
  },
}));
