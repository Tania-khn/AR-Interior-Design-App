import { create } from 'zustand';

export type AppPage = 
  | 'splash' 
  | 'landing' 
  | 'login' 
  | 'signup' 
  | 'dashboard' 
  | 'ar-view' 
  | 'catalog' 
  | 'saved' 
  | 'profile' 
  | 'settings'
  | 'design-tips'
  | 'privacy-policy'
  | 'terms-conditions';

interface AppState {
  currentPage: AppPage;
  previousPage: AppPage | null;
  selectedFurnitureId: string | null;
  navigateTo: (page: AppPage) => void;
  setSelectedFurniture: (id: string | null) => void;
}

export const useAppStore = create<AppState>((set) => ({
  currentPage: 'splash',
  previousPage: null,
  selectedFurnitureId: null,
  navigateTo: (page) => 
    set((state) => ({
      previousPage: state.currentPage,
      currentPage: page,
    })),
  setSelectedFurniture: (id) => 
    set({ selectedFurnitureId: id }),
}));
