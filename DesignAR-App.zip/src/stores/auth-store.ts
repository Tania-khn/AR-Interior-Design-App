import { create } from 'zustand';

interface User {
  id: string;
  fullName: string;
  email: string;
  createdAt: string;
}

interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<boolean>;
  signup: (fullName: string, email: string, password: string) => Promise<boolean>;
  logout: () => void;
  loadUser: () => void;
}

export const useAuthStore = create<AuthState>((set) => ({
  user: null,
  isAuthenticated: false,
  isLoading: false,

  login: async (email: string, _password: string) => {
    set({ isLoading: true });
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 800));
    
    // Check localStorage for existing users
    const storedUsers = JSON.parse(localStorage.getItem('designar_users') || '[]') as Array<User & { password: string }>;
    const found = storedUsers.find((u) => u.email === email);
    
    if (found) {
      const user: User = { id: found.id, fullName: found.fullName, email: found.email, createdAt: found.createdAt };
      localStorage.setItem('designar_current_user', JSON.stringify(user));
      set({ user, isAuthenticated: true, isLoading: false });
      return true;
    }
    
    // If no user found, create a demo login
    const demoUser: User = {
      id: crypto.randomUUID(),
      fullName: email.split('@')[0],
      email,
      createdAt: new Date().toISOString(),
    };
    localStorage.setItem('designar_current_user', JSON.stringify(demoUser));
    set({ user: demoUser, isAuthenticated: true, isLoading: false });
    return true;
  },

  signup: async (fullName: string, email: string, password: string) => {
    set({ isLoading: true });
    await new Promise((resolve) => setTimeout(resolve, 800));
    
    const newUser = {
      id: crypto.randomUUID(),
      fullName,
      email,
      password,
      createdAt: new Date().toISOString(),
    };

    const storedUsers = JSON.parse(localStorage.getItem('designar_users') || '[]') as Array<User & { password: string }>;
    storedUsers.push(newUser);
    localStorage.setItem('designar_users', JSON.stringify(storedUsers));

    const user: User = { id: newUser.id, fullName: newUser.fullName, email: newUser.email, createdAt: newUser.createdAt };
    localStorage.setItem('designar_current_user', JSON.stringify(user));
    set({ user, isAuthenticated: true, isLoading: false });
    return true;
  },

  logout: () => {
    localStorage.removeItem('designar_current_user');
    set({ user: null, isAuthenticated: false });
  },

  loadUser: () => {
    const stored = localStorage.getItem('designar_current_user');
    if (stored) {
      const user = JSON.parse(stored) as User;
      set({ user, isAuthenticated: true });
    }
  },
}));
