'use client';

import { AnimatePresence, motion } from 'framer-motion';
import { useAppStore } from '@/stores/app-store';
import SplashScreen from '@/components/app/SplashScreen';
import LandingPage from '@/components/app/LandingPage';
import LoginPage from '@/components/app/LoginPage';
import SignupPage from '@/components/app/SignupPage';
import Dashboard from '@/components/app/Dashboard';
import ARView from '@/components/app/ARView';
import FurnitureCatalog from '@/components/app/FurnitureCatalog';
import SavedDesigns from '@/components/app/SavedDesigns';
import ProfilePage from '@/components/app/ProfilePage';
import SettingsPage from '@/components/app/SettingsPage';
import DesignTipsPage from '@/components/app/DesignTipsPage';
import PrivacyPolicyPage from '@/components/app/PrivacyPolicyPage';
import TermsConditionsPage from '@/components/app/TermsConditionsPage';
import BottomNav from '@/components/app/BottomNav';

const pageVariants = {
  initial: { opacity: 0, x: 20 },
  animate: { opacity: 1, x: 0 },
  exit: { opacity: 0, x: -20 },
};

// Pages that should show the bottom navigation
const navPages = ['dashboard', 'ar-view', 'catalog', 'saved', 'profile'];

export default function Home() {
  const currentPage = useAppStore((s) => s.currentPage);

  const renderPage = () => {
    switch (currentPage) {
      case 'splash':
        return <SplashScreen />;
      case 'landing':
        return <LandingPage />;
      case 'login':
        return <LoginPage />;
      case 'signup':
        return <SignupPage />;
      case 'dashboard':
        return <Dashboard />;
      case 'ar-view':
        return <ARView />;
      case 'catalog':
        return <FurnitureCatalog />;
      case 'saved':
        return <SavedDesigns />;
      case 'profile':
        return <ProfilePage />;
      case 'settings':
        return <SettingsPage />;
      case 'design-tips':
        return <DesignTipsPage />;
      case 'privacy-policy':
        return <PrivacyPolicyPage />;
      case 'terms-conditions':
        return <TermsConditionsPage />;
      default:
        return <SplashScreen />;
    }
  };

  const showBottomNav = navPages.includes(currentPage) && currentPage !== 'ar-view';

  return (
    <div className="min-h-screen bg-background">
      <AnimatePresence mode="wait">
        <motion.div
          key={currentPage}
          variants={pageVariants}
          initial="initial"
          animate="animate"
          exit="exit"
          transition={{ duration: 0.25, ease: 'easeInOut' }}
        >
          {renderPage()}
        </motion.div>
      </AnimatePresence>
      {showBottomNav && <BottomNav />}
    </div>
  );
}
