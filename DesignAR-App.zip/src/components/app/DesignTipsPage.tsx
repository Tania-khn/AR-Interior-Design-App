'use client';

import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useAppStore } from '@/stores/app-store';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  ArrowLeft,
  Lightbulb,
  ChevronDown,
  Palette,
  Ruler,
  Sun,
  Home,
  Sparkles,
  Layout,
  Paintbrush,
} from 'lucide-react';

const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: { staggerChildren: 0.08 },
  },
};

const item = {
  hidden: { opacity: 0, y: 10 },
  show: { opacity: 1, y: 0 },
};

interface DesignTip {
  id: string;
  title: string;
  category: string;
  icon: React.ReactNode;
  summary: string;
  details: string;
  color: string;
}

const designTips: DesignTip[] = [
  {
    id: '1',
    title: 'Lighting Matters',
    category: 'Lighting',
    icon: <Sun className="w-5 h-5" />,
    summary: 'Layer your lighting for depth and ambiance.',
    details:
      'Every room needs three layers of lighting: ambient (general illumination), task (for specific activities like reading or cooking), and accent (to highlight architectural features or artwork). Use dimmers to control the mood and combine warm and cool tones. Place table lamps at different heights to create visual interest and eliminate dark corners.',
    color: 'from-amber-500 to-orange-500',
  },
  {
    id: '2',
    title: 'Measure First',
    category: 'Planning',
    icon: <Ruler className="w-5 h-5" />,
    summary: 'Always measure your space before buying furniture.',
    details:
      'Before purchasing any furniture, measure your room dimensions including doorways, windows, and ceiling height. Create a floor plan (even a simple sketch works) and leave at least 36 inches for walkways. Consider the scale of furniture relative to your room — oversized pieces in small rooms make the space feel cramped, while tiny pieces in large rooms look lost.',
    color: 'from-blue-500 to-indigo-500',
  },
  {
    id: '3',
    title: 'Color Harmony',
    category: 'Color',
    icon: <Palette className="w-5 h-5" />,
    summary: 'Use the 60-30-10 rule for balanced color schemes.',
    details:
      'The 60-30-10 rule is a timeless interior design principle: 60% of the room should be your dominant color (walls, large furniture), 30% should be your secondary color (curtains, accent chairs, bedding), and 10% should be your accent color (throw pillows, artwork, decorative objects). This creates visual balance without feeling overwhelming.',
    color: 'from-purple-500 to-pink-500',
  },
  {
    id: '4',
    title: 'Create a Focal Point',
    category: 'Layout',
    icon: <Layout className="w-5 h-5" />,
    summary: 'Every room needs a visual anchor point.',
    details:
      'A focal point draws the eye and gives the room purpose. It could be a fireplace, a large window with a view, an accent wall, or a statement piece of furniture. Arrange your seating to face the focal point and keep the area around it uncluttered. If your room lacks a natural focal point, create one with bold artwork, a striking light fixture, or a dramatic piece of furniture.',
    color: 'from-emerald-500 to-teal-500',
  },
  {
    id: '5',
    title: 'Mix Textures',
    category: 'Style',
    icon: <Paintbrush className="w-5 h-5" />,
    summary: 'Combine different textures for a rich, layered look.',
    details:
      'Texture adds depth and interest to any space. Mix smooth surfaces (glass, metal, leather) with rough ones (woven baskets, nubby fabrics, reclaimed wood). In a neutral room, texture becomes especially important — a linen sofa, a wool rug, and a velvet pillow in the same color family create a sophisticated, layered look. Don\'t forget to incorporate plants for natural texture.',
    color: 'from-rose-500 to-red-500',
  },
  {
    id: '6',
    title: 'The Power of Mirrors',
    category: 'Lighting',
    icon: <Sparkles className="w-5 h-5" />,
    summary: 'Strategic mirror placement can double your space visually.',
    details:
      'Mirrors reflect light and create the illusion of more space. Place a large mirror opposite a window to bounce natural light around the room. In narrow hallways, mirrors can make the space feel wider. For dining rooms, a mirrored backsplash adds glamour. Avoid placing mirrors where they reflect clutter or unattractive views. Lean oversized mirrors against walls for a casual, modern look.',
    color: 'from-cyan-500 to-blue-500',
  },
  {
    id: '7',
    title: 'Scale & Proportion',
    category: 'Planning',
    icon: <Home className="w-5 h-5" />,
    summary: 'Choose furniture that fits the scale of your room.',
    details:
      'Scale refers to how items relate to the room size, while proportion is about how items relate to each other. In high-ceiling rooms, use tall bookcases and pendant lights. For small spaces, choose furniture with exposed legs to create a sense of openness. The coffee table should be about two-thirds the length of your sofa. Mix sizes but maintain visual balance — pair a substantial sofa with equally weighty accent chairs.',
    color: 'from-violet-500 to-purple-500',
  },
  {
    id: '8',
    title: 'Less is More',
    category: 'Style',
    icon: <Lightbulb className="w-5 h-5" />,
    summary: 'Edit your space — remove unnecessary items for clarity.',
    details:
      'Clutter is the enemy of good design. Start by removing everything from a surface, then add back only what serves a purpose or brings you joy. Leave some breathing room between objects — negative space is just as important as filled space. Choose fewer, higher-quality accessories over many small knickknacks. Remember: you can always add more later, but editing creates sophistication.',
    color: 'from-slate-500 to-gray-600',
  },
];

export default function DesignTipsPage() {
  const navigateTo = useAppStore((s) => s.navigateTo);
  const [expandedTip, setExpandedTip] = useState<string | null>(null);

  const toggleTip = (id: string) => {
    setExpandedTip(expandedTip === id ? null : id);
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <motion.header
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        className="sticky top-0 z-40 bg-background/95 backdrop-blur-md border-b border-border"
      >
        <div className="flex items-center px-4 py-3 gap-3">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => navigateTo('settings')}
            className="w-9 h-9"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <h1 className="text-lg font-bold text-foreground">Design Tips</h1>
        </div>
      </motion.header>

      <motion.div
        variants={container}
        initial="hidden"
        animate="show"
        className="px-4 sm:px-6 pt-4 space-y-3 pb-10"
      >
        {/* Intro */}
        <motion.div variants={item} className="mb-2">
          <p className="text-sm text-muted-foreground">
            Tap any tip to learn more about professional interior design principles.
          </p>
        </motion.div>

        {/* Tip Cards */}
        {designTips.map((tip) => (
          <motion.div key={tip.id} variants={item}>
            <Card className="border-border overflow-hidden">
              <CardContent className="p-0">
                <button
                  onClick={() => toggleTip(tip.id)}
                  className="w-full text-left"
                >
                  <div className="flex items-start gap-3 p-4">
                    <div
                      className={`w-10 h-10 rounded-xl bg-gradient-to-br ${tip.color} flex items-center justify-center text-white shrink-0`}
                    >
                      {tip.icon}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <h3 className="text-sm font-semibold text-foreground">
                          {tip.title}
                        </h3>
                        <Badge variant="secondary" className="text-[10px] px-1.5 py-0">
                          {tip.category}
                        </Badge>
                      </div>
                      <p className="text-xs text-muted-foreground">
                        {tip.summary}
                      </p>
                    </div>
                    <motion.div
                      animate={{ rotate: expandedTip === tip.id ? 180 : 0 }}
                      transition={{ duration: 0.2 }}
                      className="shrink-0 mt-1"
                    >
                      <ChevronDown className="w-4 h-4 text-muted-foreground" />
                    </motion.div>
                  </div>
                </button>

                <AnimatePresence>
                  {expandedTip === tip.id && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.3, ease: 'easeInOut' }}
                      className="overflow-hidden"
                    >
                      <div className="px-4 pb-4 pt-0">
                        <div className="h-px bg-border mb-3" />
                        <p className="text-xs leading-relaxed text-muted-foreground">
                          {tip.details}
                        </p>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </motion.div>
    </div>
  );
}
