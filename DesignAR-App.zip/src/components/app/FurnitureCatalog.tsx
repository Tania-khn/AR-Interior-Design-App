'use client';

import { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useAppStore } from '@/stores/app-store';
import { furnitureItems, categories, categoryEmojis, type FurnitureCategory } from '@/lib/furniture-data';
import { useDesignStore, type PlacedFurniture } from '@/stores/design-store';
import ThemeToggle from './ThemeToggle';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Search, Plus, ArrowRight, Ruler } from 'lucide-react';
import { toast } from 'sonner';

const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: { staggerChildren: 0.05 },
  },
};

const item = {
  hidden: { opacity: 0, scale: 0.95 },
  show: { opacity: 1, scale: 1 },
};

export default function FurnitureCatalog() {
  const navigateTo = useAppStore((s) => s.navigateTo);
  const setSelectedFurniture = useAppStore((s) => s.setSelectedFurniture);
  const addItem = useDesignStore((s) => s.addItem);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState<FurnitureCategory | 'All'>('All');

  const filteredItems = useMemo(() => {
    let items = furnitureItems;
    if (activeCategory !== 'All') {
      items = items.filter((i) => i.category === activeCategory);
    }
    if (searchQuery.trim()) {
      const lower = searchQuery.toLowerCase();
      items = items.filter(
        (i) =>
          i.name.toLowerCase().includes(lower) ||
          i.description.toLowerCase().includes(lower)
      );
    }
    return items;
  }, [searchQuery, activeCategory]);

  const handleAddToRoom = (furniture: typeof furnitureItems[0]) => {
    const newItem: PlacedFurniture = {
      id: crypto.randomUUID(),
      furnitureId: furniture.id,
      name: furniture.name,
      emoji: furniture.emoji,
      x: 30 + Math.random() * 40,
      y: 35 + Math.random() * 30,
      rotation: 0,
      scale: 1,
      color: furniture.color,
      colors: furniture.colors,
    };
    addItem(newItem);
    toast.success(`${furniture.name} added to room`);
  };

  const handleAddAndOpen = (furniture: typeof furnitureItems[0]) => {
    // Add the item directly to the room AND navigate to AR view
    // This is more reliable than using selectedFurnitureId across page transitions
    const newItem: PlacedFurniture = {
      id: crypto.randomUUID(),
      furnitureId: furniture.id,
      name: furniture.name,
      emoji: furniture.emoji,
      x: 30 + Math.random() * 40,
      y: 35 + Math.random() * 30,
      rotation: 0,
      scale: 1,
      color: furniture.color,
      colors: furniture.colors,
    };
    addItem(newItem);
    // Store the new item ID so ARView can auto-select it
    setSelectedFurniture(newItem.id);
    navigateTo('ar-view');
  };

  return (
    <div className="min-h-screen bg-background pb-20">
      {/* Header */}
      <motion.header
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        className="sticky top-0 z-40 bg-background/95 backdrop-blur-md border-b border-border"
      >
        <div className="flex items-center justify-between px-4 py-3">
          <h1 className="text-lg font-bold text-foreground">Furniture Catalog</h1>
          <ThemeToggle />
        </div>

        {/* Search */}
        <div className="px-4 pb-3">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search furniture..."
              className="pl-9 h-10 bg-muted/50"
            />
          </div>
        </div>

        {/* Category Tabs */}
        <div className="flex gap-2 px-4 pb-3 overflow-x-auto -mx-1">
          <Button
            variant={activeCategory === 'All' ? 'default' : 'outline'}
            size="sm"
            onClick={() => setActiveCategory('All')}
            className="flex-shrink-0 text-xs"
          >
            All
          </Button>
          {categories.map((cat) => (
            <Button
              key={cat}
              variant={activeCategory === cat ? 'default' : 'outline'}
              size="sm"
              onClick={() => setActiveCategory(cat)}
              className="flex-shrink-0 text-xs"
            >
              {categoryEmojis[cat]} {cat}
            </Button>
          ))}
        </div>
      </motion.header>

      {/* Results count */}
      <div className="px-4 py-2">
        <p className="text-xs text-muted-foreground">
          {filteredItems.length} item{filteredItems.length !== 1 ? 's' : ''} found
        </p>
      </div>

      {/* Items Grid */}
      <AnimatePresence mode="wait">
        <motion.div
          key={activeCategory + searchQuery}
          variants={container}
          initial="hidden"
          animate="show"
          className="px-4 grid grid-cols-2 gap-3"
        >
          {filteredItems.map((furniture) => (
            <motion.div
              key={furniture.id}
              variants={item}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              <Card className="border-border overflow-hidden">
                {/* Item Visual */}
                <div className="h-28 sm:h-32 flex items-center justify-center bg-gradient-to-br from-muted/50 to-muted/20 relative">
                  <span className="text-5xl sm:text-6xl">{furniture.emoji}</span>
                  <Badge className="absolute top-2 left-2 text-[10px] bg-card/80 backdrop-blur-sm">
                    {furniture.category}
                  </Badge>
                </div>

                <CardContent className="p-3">
                  <h3 className="font-semibold text-sm text-foreground truncate">
                    {furniture.name}
                  </h3>

                  <div className="flex items-center gap-1 mt-1">
                    <Ruler className="w-3 h-3 text-muted-foreground" />
                    <span className="text-[10px] text-muted-foreground">
                      {furniture.width}×{furniture.depth}×{furniture.height} cm
                    </span>
                  </div>

                  {/* Color options */}
                  <div className="flex items-center gap-1 mt-2">
                    {furniture.colors.slice(0, 4).map((color) => (
                      <div
                        key={color}
                        className="w-4 h-4 rounded-full border border-border"
                        style={{ backgroundColor: color }}
                      />
                    ))}
                  </div>

                  {/* Price */}
                  <p className="text-sm font-bold text-primary mt-2">
                    ${furniture.price}
                  </p>

                  {/* Action Buttons */}
                  <div className="flex gap-1.5 mt-2">
                    <Button
                      size="sm"
                      className="flex-1 h-8 text-xs bg-primary hover:bg-primary/90"
                      onClick={() => handleAddAndOpen(furniture)}
                    >
                      <ArrowRight className="w-3 h-3 mr-1" />
                      Add to Room
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      className="h-8 w-8 p-0 border-primary text-primary"
                      onClick={() => handleAddToRoom(furniture)}
                    >
                      <Plus className="w-3 h-3" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </motion.div>
      </AnimatePresence>

      {/* Empty State */}
      {filteredItems.length === 0 && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="flex flex-col items-center justify-center py-16 px-4"
        >
          <span className="text-4xl">🔍</span>
          <p className="font-semibold text-foreground mt-3">No items found</p>
          <p className="text-sm text-muted-foreground mt-1">
            Try a different search or category
          </p>
          <Button
            variant="outline"
            onClick={() => {
              setSearchQuery('');
              setActiveCategory('All');
            }}
            className="mt-3"
            size="sm"
          >
            Clear Filters
          </Button>
        </motion.div>
      )}
    </div>
  );
}
