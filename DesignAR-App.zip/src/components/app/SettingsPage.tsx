'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import { useAppStore } from '@/stores/app-store';
import { useDesignStore } from '@/stores/design-store';
import { useTheme } from 'next-themes';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  ArrowLeft,
  Sun,
  Moon,
  Monitor,
  Grid3X3,
  Magnet,
  Ruler,
  Bell,
  Globe,
  Info,
  Shield,
  FileText,
  SunMoon,
  Mail,
  Phone,
  Globe2,
  MapPin,
  Copy,
  Check,
  Lightbulb,
  ChevronRight,
  Scale,
  BookOpen,
  Headphones,
} from 'lucide-react';
import { toast } from 'sonner';

const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: { staggerChildren: 0.06 },
  },
};

const item = {
  hidden: { opacity: 0, y: 10 },
  show: { opacity: 1, y: 0 },
};

function CopyButton({ text, label }: { text: string; label: string }) {
  const [copied, setCopied] = useState(false);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      toast.success(`${label} copied to clipboard`);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      toast.error('Failed to copy');
    }
  };

  return (
    <button
      onClick={handleCopy}
      className="ml-2 shrink-0 p-1 rounded-md hover:bg-white/20 transition-colors"
      title={`Copy ${label}`}
    >
      {copied ? (
        <Check className="w-3.5 h-3.5 text-green-300" />
      ) : (
        <Copy className="w-3.5 h-3.5 text-white/70 hover:text-white" />
      )}
    </button>
  );
}

export default function SettingsPage() {
  const navigateTo = useAppStore((s) => s.navigateTo);
  const arSettings = useDesignStore((s) => s.arSettings);
  const updateArSettings = useDesignStore((s) => s.updateArSettings);
  const { theme, setTheme } = useTheme();

  const [notifications, setNotifications] = useState({
    designSaved: true,
    newFeatures: true,
    tips: false,
  });

  const [language, setLanguage] = useState('en');

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <motion.header
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        className="sticky top-0 z-40 bg-background/95 backdrop-blur-md border-b border-border"
      >
        <div className="flex items-center px-4 py-3 gap-3">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => navigateTo('profile')}
            className="w-9 h-9"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <h1 className="text-lg font-bold text-foreground">Settings</h1>
        </div>
      </motion.header>

      <motion.div
        variants={container}
        initial="hidden"
        animate="show"
        className="px-4 sm:px-6 pt-4 space-y-6 pb-10"
      >
        {/* Theme Section */}
        <motion.div variants={item}>
          <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-3">
            Appearance
          </h2>
          <Card className="border-border">
            <CardContent className="p-0">
              <div className="px-4 py-3">
                <div className="flex items-center gap-3 mb-3">
                  <SunMoon className="w-5 h-5 text-primary" />
                  <Label className="text-sm font-medium text-foreground">Theme</Label>
                </div>
                <div className="grid grid-cols-3 gap-2">
                  <button
                    onClick={() => setTheme('light')}
                    className={`flex flex-col items-center gap-1.5 p-3 rounded-lg border transition-colors ${
                      theme === 'light'
                        ? 'border-primary bg-primary/10'
                        : 'border-border hover:border-primary/50'
                    }`}
                  >
                    <Sun className={`w-5 h-5 ${theme === 'light' ? 'text-primary' : 'text-muted-foreground'}`} />
                    <span className="text-xs font-medium">Light</span>
                  </button>
                  <button
                    onClick={() => setTheme('dark')}
                    className={`flex flex-col items-center gap-1.5 p-3 rounded-lg border transition-colors ${
                      theme === 'dark'
                        ? 'border-primary bg-primary/10'
                        : 'border-border hover:border-primary/50'
                    }`}
                  >
                    <Moon className={`w-5 h-5 ${theme === 'dark' ? 'text-primary' : 'text-muted-foreground'}`} />
                    <span className="text-xs font-medium">Dark</span>
                  </button>
                  <button
                    onClick={() => setTheme('system')}
                    className={`flex flex-col items-center gap-1.5 p-3 rounded-lg border transition-colors ${
                      theme === 'system'
                        ? 'border-primary bg-primary/10'
                        : 'border-border hover:border-primary/50'
                    }`}
                  >
                    <Monitor className={`w-5 h-5 ${theme === 'system' ? 'text-primary' : 'text-muted-foreground'}`} />
                    <span className="text-xs font-medium">System</span>
                  </button>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Notifications */}
        <motion.div variants={item}>
          <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-3">
            <Bell className="w-4 h-4 inline mr-1" />
            Notifications
          </h2>
          <Card className="border-border">
            <CardContent className="p-0 divide-y divide-border">
              <div className="flex items-center justify-between px-4 py-3">
                <div>
                  <Label className="text-sm font-medium text-foreground">Design Saved</Label>
                  <p className="text-xs text-muted-foreground">Notify when design is saved</p>
                </div>
                <Switch
                  checked={notifications.designSaved}
                  onCheckedChange={(checked) =>
                    setNotifications((n) => ({ ...n, designSaved: checked }))
                  }
                />
              </div>
              <div className="flex items-center justify-between px-4 py-3">
                <div>
                  <Label className="text-sm font-medium text-foreground">New Features</Label>
                  <p className="text-xs text-muted-foreground">Get updates about new features</p>
                </div>
                <Switch
                  checked={notifications.newFeatures}
                  onCheckedChange={(checked) =>
                    setNotifications((n) => ({ ...n, newFeatures: checked }))
                  }
                />
              </div>
              <div className="flex items-center justify-between px-4 py-3">
                <div>
                  <Label className="text-sm font-medium text-foreground">Design Tips</Label>
                  <p className="text-xs text-muted-foreground">Daily interior design tips</p>
                </div>
                <Switch
                  checked={notifications.tips}
                  onCheckedChange={(checked) =>
                    setNotifications((n) => ({ ...n, tips: checked }))
                  }
                />
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Language */}
        <motion.div variants={item}>
          <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-3">
            <Globe className="w-4 h-4 inline mr-1" />
            Language
          </h2>
          <Card className="border-border">
            <CardContent className="p-4">
              <Select value={language} onValueChange={setLanguage}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="en">English</SelectItem>
                  <SelectItem value="es">Español</SelectItem>
                  <SelectItem value="fr">Français</SelectItem>
                  <SelectItem value="de">Deutsch</SelectItem>
                  <SelectItem value="zh">中文</SelectItem>
                  <SelectItem value="ja">日本語</SelectItem>
                </SelectContent>
              </Select>
            </CardContent>
          </Card>
        </motion.div>

        {/* AR Settings */}
        <motion.div variants={item}>
          <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-3">
            AR Settings
          </h2>
          <Card className="border-border">
            <CardContent className="p-0 divide-y divide-border">
              <div className="flex items-center justify-between px-4 py-3">
                <div className="flex items-center gap-3">
                  <Grid3X3 className="w-5 h-5 text-primary" />
                  <div>
                    <Label className="text-sm font-medium text-foreground">Show Grid</Label>
                    <p className="text-xs text-muted-foreground">Display floor grid in AR view</p>
                  </div>
                </div>
                <Switch
                  checked={arSettings.showGrid}
                  onCheckedChange={(checked) => updateArSettings({ showGrid: checked })}
                />
              </div>
              <div className="flex items-center justify-between px-4 py-3">
                <div className="flex items-center gap-3">
                  <Magnet className="w-5 h-5 text-primary" />
                  <div>
                    <Label className="text-sm font-medium text-foreground">Snap to Grid</Label>
                    <p className="text-xs text-muted-foreground">Auto-snap furniture to grid</p>
                  </div>
                </div>
                <Switch
                  checked={arSettings.snapToGrid}
                  onCheckedChange={(checked) => updateArSettings({ snapToGrid: checked })}
                />
              </div>
              <div className="flex items-center justify-between px-4 py-3">
                <div className="flex items-center gap-3">
                  <Ruler className="w-5 h-5 text-primary" />
                  <div>
                    <Label className="text-sm font-medium text-foreground">Measurement Units</Label>
                    <p className="text-xs text-muted-foreground">Choose your preferred unit</p>
                  </div>
                </div>
                <Select
                  value={arSettings.measurementUnit}
                  onValueChange={(value) =>
                    updateArSettings({ measurementUnit: value as 'cm' | 'inches' })
                  }
                >
                  <SelectTrigger className="w-24 h-8 text-xs">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="cm">cm</SelectItem>
                    <SelectItem value="inches">inches</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Contact Support Section */}
        <motion.div variants={item}>
          <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-3">
            <Headphones className="w-4 h-4 inline mr-1" />
            Contact Support
          </h2>
          <div className="rounded-xl overflow-hidden bg-gradient-to-br from-purple-600 via-indigo-600 to-violet-700 p-[1px]">
            <div className="rounded-xl bg-gradient-to-br from-purple-600 via-indigo-600 to-violet-700 p-4 space-y-3">
              <div className="flex items-center gap-2 mb-1">
                <Headphones className="w-5 h-5 text-white" />
                <h3 className="text-sm font-bold text-white">Get in Touch</h3>
              </div>
              <p className="text-xs text-purple-200 mb-3">
                We&apos;re here to help with any questions or issues.
              </p>

              {/* Email */}
              <div className="flex items-center justify-between bg-white/10 rounded-lg px-3 py-2.5">
                <div className="flex items-center gap-2.5 min-w-0">
                  <Mail className="w-4 h-4 text-purple-200 shrink-0" />
                  <span className="text-xs text-white truncate">support@designar.app</span>
                </div>
                <CopyButton text="support@designar.app" label="Email" />
              </div>

              {/* Phone */}
              <div className="flex items-center justify-between bg-white/10 rounded-lg px-3 py-2.5">
                <div className="flex items-center gap-2.5 min-w-0">
                  <Phone className="w-4 h-4 text-purple-200 shrink-0" />
                  <span className="text-xs text-white truncate">+1 (555) 123-4567</span>
                </div>
                <CopyButton text="+1 (555) 123-4567" label="Phone" />
              </div>

              {/* Website */}
              <div className="flex items-center justify-between bg-white/10 rounded-lg px-3 py-2.5">
                <div className="flex items-center gap-2.5 min-w-0">
                  <Globe2 className="w-4 h-4 text-purple-200 shrink-0" />
                  <span className="text-xs text-white truncate">www.designar.app</span>
                </div>
                <CopyButton text="www.designar.app" label="Website" />
              </div>

              {/* Address */}
              <div className="flex items-center justify-between bg-white/10 rounded-lg px-3 py-2.5">
                <div className="flex items-center gap-2.5 min-w-0">
                  <MapPin className="w-4 h-4 text-purple-200 shrink-0" />
                  <span className="text-xs text-white truncate">123 Design St, Creative City, CA 90210</span>
                </div>
                <CopyButton text="123 Design Street, Creative City, CA 90210" label="Address" />
              </div>
            </div>
          </div>
        </motion.div>

        {/* Legal Section */}
        <motion.div variants={item}>
          <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-3">
            <Scale className="w-4 h-4 inline mr-1" />
            Legal
          </h2>
          <Card className="border-border">
            <CardContent className="p-0 divide-y divide-border">
              <button
                onClick={() => navigateTo('privacy-policy')}
                className="flex items-center justify-between w-full px-4 py-3.5 hover:bg-muted/50 transition-colors"
              >
                <div className="flex items-center gap-3">
                  <Shield className="w-4 h-4 text-muted-foreground" />
                  <span className="text-sm text-foreground">Privacy Policy</span>
                </div>
                <ChevronRight className="w-4 h-4 text-muted-foreground" />
              </button>
              <button
                onClick={() => navigateTo('terms-conditions')}
                className="flex items-center justify-between w-full px-4 py-3.5 hover:bg-muted/50 transition-colors"
              >
                <div className="flex items-center gap-3">
                  <FileText className="w-4 h-4 text-muted-foreground" />
                  <span className="text-sm text-foreground">Terms & Conditions</span>
                </div>
                <ChevronRight className="w-4 h-4 text-muted-foreground" />
              </button>
            </CardContent>
          </Card>
        </motion.div>

        {/* Learn Section */}
        <motion.div variants={item}>
          <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-3">
            <BookOpen className="w-4 h-4 inline mr-1" />
            Learn
          </h2>
          <Card className="border-border">
            <CardContent className="p-0">
              <button
                onClick={() => navigateTo('design-tips')}
                className="flex items-center justify-between w-full px-4 py-3.5 hover:bg-muted/50 transition-colors"
              >
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-amber-400 to-orange-500 flex items-center justify-center">
                    <Lightbulb className="w-4 h-4 text-white" />
                  </div>
                  <div className="text-left">
                    <span className="text-sm font-medium text-foreground block">Design Tips</span>
                    <span className="text-xs text-muted-foreground">Professional interior design advice</span>
                  </div>
                </div>
                <ChevronRight className="w-4 h-4 text-muted-foreground" />
              </button>
            </CardContent>
          </Card>
        </motion.div>

        {/* About */}
        <motion.div variants={item}>
          <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-3">
            <Info className="w-4 h-4 inline mr-1" />
            About
          </h2>
          <Card className="border-border">
            <CardContent className="p-0 divide-y divide-border">
              <div className="flex items-center justify-between px-4 py-3">
                <span className="text-sm text-foreground">App Version</span>
                <span className="text-xs font-semibold text-primary bg-primary/10 px-2.5 py-0.5 rounded-full">v2.0.0</span>
              </div>
              <div className="flex items-center justify-between px-4 py-3">
                <span className="text-sm text-foreground">App Name</span>
                <span className="text-sm text-muted-foreground">DesignAR</span>
              </div>
              <div className="flex items-center justify-between px-4 py-3">
                <span className="text-sm text-foreground">Release Date</span>
                <span className="text-sm text-muted-foreground">June 2026</span>
              </div>
              <div className="flex items-center justify-between px-4 py-3">
                <span className="text-sm text-foreground">Platform</span>
                <span className="text-sm text-muted-foreground">Web / Mobile</span>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* App info footer */}
        <motion.div variants={item} className="text-center pt-2 pb-4">
          <div className="flex items-center justify-center gap-2 mb-2">
            <img src="/logo.png" alt="DesignAR" className="w-6 h-6" />
            <span className="text-sm font-bold text-foreground">
              Design<span className="text-primary">AR</span>
            </span>
            <span className="text-[10px] font-medium text-primary bg-primary/10 px-1.5 py-0.5 rounded-full">v2.0.0</span>
          </div>
          <p className="text-xs text-muted-foreground">
            AR-Based Interior Design Mobile Application
          </p>
          <p className="text-xs text-muted-foreground mt-1">
            University Project &copy; 2026
          </p>
        </motion.div>
      </motion.div>
    </div>
  );
}
