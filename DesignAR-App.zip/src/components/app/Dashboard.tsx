'use client';

import { useEffect } from 'react';
import { motion } from 'framer-motion';
import { useAppStore } from '@/stores/app-store';
import { useAuthStore } from '@/stores/auth-store';
import { useDesignStore } from '@/stores/design-store';
import ThemeToggle from './ThemeToggle';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  Box,
  Armchair,
  FolderOpen,
  Settings,
  Lightbulb,
  Sparkles,
  ArrowRight,
} from 'lucide-react';

const quickActions = [
  {
    icon: Box,
    title: 'Start AR Design',
    description: 'Place furniture in AR',
    page: 'ar-view' as const,
    color: 'text-teal-600 dark:text-teal-400',
    bg: 'bg-teal-100 dark:bg-teal-900/30',
  },
  {
    icon: Armchair,
    title: 'Browse Catalog',
    description: 'Explore furniture',
    page: 'catalog' as const,
    color: 'text-amber-600 dark:text-amber-400',
    bg: 'bg-amber-100 dark:bg-amber-900/30',
  },
  {
    icon: FolderOpen,
    title: 'My Designs',
    description: 'View saved rooms',
    page: 'saved' as const,
    color: 'text-emerald-600 dark:text-emerald-400',
    bg: 'bg-emerald-100 dark:bg-emerald-900/30',
  },
  {
    icon: Settings,
    title: 'Settings',
    description: 'Customize app',
    page: 'settings' as const,
    color: 'text-rose-600 dark:text-rose-400',
    bg: 'bg-rose-100 dark:bg-rose-900/30',
  },
];

const tips = [
  {
    emoji: '💡',
    title: 'Lighting Matters',
    text: 'Place lamps near seating areas for the best ambiance',
  },
  {
    emoji: '📏',
    title: 'Measure First',
    text: 'Always measure your room before placing furniture',
  },
  {
    emoji: '🎨',
    title: 'Color Harmony',
    text: 'Stick to 2-3 colors for a cohesive room design',
  },
];

const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: { staggerChildren: 0.08 },
  },
};

const item = {
  hidden: { opacity: 0, y: 15 },
  show: { opacity: 1, y: 0 },
};

export default function Dashboard() {
  const navigateTo = useAppStore((s) => s.navigateTo);
  const user = useAuthStore((s) => s.user);
  const loadSavedDesigns = useDesignStore((s) => s.loadSavedDesigns);
  const savedDesigns = useDesignStore((s) => s.savedDesigns);

  useEffect(() => {
    loadSavedDesigns();
  }, [loadSavedDesigns]);

  const firstName = user?.fullName?.split(' ')[0] || 'Designer';
  const recentDesigns = savedDesigns.slice(0, 3);

  return (
    <div className="min-h-screen bg-background pb-20">
      {/* Header */}
      <motion.header
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        className="sticky top-0 z-40 bg-background/95 backdrop-blur-md border-b border-border"
      >
        <div className="flex items-center justify-between px-4 py-3">
          <div className="flex items-center gap-2">
            <img src="/logo.png" alt="DesignAR" className="w-8 h-8" />
            <span className="text-lg font-bold text-foreground">
              Design<span className="text-primary">AR</span>
            </span>
            <span className="text-[10px] font-medium text-primary bg-primary/10 px-1.5 py-0.5 rounded-full">v2.0.0</span>
          </div>
          <ThemeToggle />
        </div>
      </motion.header>

      <motion.div
        variants={container}
        initial="hidden"
        animate="show"
        className="px-4 sm:px-6 pt-4 space-y-6"
      >
        {/* Welcome Section */}
        <motion.div variants={item}>
          <h1 className="text-2xl font-bold text-foreground">
            Hello, {firstName}! 👋
          </h1>
          <p className="text-muted-foreground text-sm mt-1">
            Ready to design your perfect space?
          </p>
        </motion.div>

        {/* Quick Actions */}
        <motion.div variants={item}>
          <div className="grid grid-cols-2 gap-3">
            {quickActions.map((action) => (
              <motion.div
                key={action.title}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.97 }}
              >
                <Card
                  className="cursor-pointer border-border hover:shadow-md transition-shadow"
                  onClick={() => navigateTo(action.page)}
                >
                  <CardContent className="p-4">
                    <div
                      className={`w-10 h-10 rounded-lg ${action.bg} flex items-center justify-center mb-2`}
                    >
                      <action.icon className={`w-5 h-5 ${action.color}`} />
                    </div>
                    <h3 className="font-semibold text-sm text-foreground">
                      {action.title}
                    </h3>
                    <p className="text-xs text-muted-foreground mt-0.5">
                      {action.description}
                    </p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Recent Designs */}
        <motion.div variants={item}>
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-lg font-bold text-foreground">Recent Designs</h2>
            {savedDesigns.length > 0 && (
              <Button
                variant="ghost"
                size="sm"
                onClick={() => navigateTo('saved')}
                className="text-primary text-xs"
              >
                View All <ArrowRight className="w-3 h-3 ml-1" />
              </Button>
            )}
          </div>

          {recentDesigns.length > 0 ? (
            <div className="flex gap-3 overflow-x-auto pb-2 -mx-4 px-4">
              {recentDesigns.map((design) => (
                <motion.div
                  key={design.id}
                  whileHover={{ scale: 1.03 }}
                  whileTap={{ scale: 0.97 }}
                  className="min-w-[160px]"
                >
                  <Card
                    className="cursor-pointer border-border"
                    onClick={() => {
                      useDesignStore.getState().loadDesign(design.id);
                      navigateTo('ar-view');
                    }}
                  >
                    <CardContent className="p-3">
                      <div className="w-full h-24 rounded-lg bg-gradient-to-br from-teal-100 to-emerald-100 dark:from-teal-900/40 dark:to-emerald-900/40 flex items-center justify-center text-3xl mb-2">
                        🏠
                      </div>
                      <h4 className="font-semibold text-sm text-foreground truncate">
                        {design.name}
                      </h4>
                      <div className="flex items-center gap-2 mt-1">
                        <Badge variant="secondary" className="text-[10px] px-1.5 py-0">
                          {design.roomType}
                        </Badge>
                        <span className="text-[10px] text-muted-foreground">
                          {design.items.length} items
                        </span>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          ) : (
            <Card className="border-dashed border-border">
              <CardContent className="py-8 flex flex-col items-center text-center">
                <div className="w-12 h-12 rounded-full bg-muted flex items-center justify-center mb-3">
                  <Sparkles className="w-5 h-5 text-muted-foreground" />
                </div>
                <p className="text-sm font-medium text-foreground">No designs yet</p>
                <p className="text-xs text-muted-foreground mt-1">
                  Start creating your first room design
                </p>
                <Button
                  onClick={() => navigateTo('ar-view')}
                  className="mt-3 bg-primary hover:bg-primary/90"
                  size="sm"
                >
                  <Box className="w-4 h-4 mr-1" />
                  Start Designing
                </Button>
              </CardContent>
            </Card>
          )}
        </motion.div>

        {/* Tips Section */}
        <motion.div variants={item}>
          <div className="flex items-center gap-2 mb-3">
            <Lightbulb className="w-4 h-4 text-amber-500" />
            <h2 className="text-lg font-bold text-foreground">Design Tips</h2>
          </div>
          <div className="space-y-2">
            {tips.map((tip) => (
              <Card key={tip.title} className="border-border">
                <CardContent className="p-3 flex items-start gap-3">
                  <span className="text-xl">{tip.emoji}</span>
                  <div>
                    <h4 className="font-semibold text-sm text-foreground">
                      {tip.title}
                    </h4>
                    <p className="text-xs text-muted-foreground">{tip.text}</p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </motion.div>
      </motion.div>
    </div>
  );
}
