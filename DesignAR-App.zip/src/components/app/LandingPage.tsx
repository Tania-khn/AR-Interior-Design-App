'use client';

import { motion } from 'framer-motion';
import { useAppStore } from '@/stores/app-store';
import { Button } from '@/components/ui/button';
import { Sparkles, Eye, BookOpen, Save, Share2 } from 'lucide-react';

const features = [
  {
    icon: Eye,
    title: 'AR Visualization',
    description: 'See furniture in your room before buying',
    color: 'text-teal-600 dark:text-teal-400',
    bg: 'bg-teal-100 dark:bg-teal-900/30',
  },
  {
    icon: BookOpen,
    title: 'Furniture Catalog',
    description: 'Browse 100+ furniture items in 5 categories',
    color: 'text-amber-600 dark:text-amber-400',
    bg: 'bg-amber-100 dark:bg-amber-900/30',
  },
  {
    icon: Sparkles,
    title: 'Room Design',
    description: 'Design and customize your perfect room layout',
    color: 'text-emerald-600 dark:text-emerald-400',
    bg: 'bg-emerald-100 dark:bg-emerald-900/30',
  },
  {
    icon: Save,
    title: 'Save & Share',
    description: 'Save designs and share with friends',
    color: 'text-rose-600 dark:text-rose-400',
    bg: 'bg-rose-100 dark:bg-rose-900/30',
  },
];

export default function LandingPage() {
  const navigateTo = useAppStore((s) => s.navigateTo);

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <motion.header
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="flex items-center justify-between px-4 py-3 sm:px-6"
      >
        <div className="flex items-center gap-2">
          <img src="/logo.png" alt="DesignAR" className="w-8 h-8" />
          <span className="text-lg font-bold text-foreground">
            Design<span className="text-primary">AR</span>
          </span>
        </div>
        <Button
          variant="ghost"
          size="sm"
          onClick={() => navigateTo('login')}
          className="text-primary font-medium"
        >
          Sign In
        </Button>
      </motion.header>

      {/* Hero Section */}
      <section className="px-4 sm:px-6 pt-4 pb-8">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="relative overflow-hidden rounded-2xl"
        >
          <img
            src="/hero-image.png"
            alt="AR Room Visualization"
            className="w-full h-48 sm:h-64 md:h-80 object-cover rounded-2xl"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent rounded-2xl" />
          <div className="absolute bottom-0 left-0 right-0 p-4 sm:p-6">
            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="text-2xl sm:text-3xl md:text-4xl font-bold text-white leading-tight"
            >
              Design Your Space
              <br />
              <span className="text-amber-300">with AR</span>
            </motion.h1>
            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.5 }}
              className="mt-2 text-white/80 text-sm sm:text-base max-w-md"
            >
              Visualize furniture in your room using augmented reality before you buy
            </motion.p>
          </div>
        </motion.div>

        {/* CTA Buttons */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="mt-6 flex gap-3"
        >
          <Button
            onClick={() => navigateTo('signup')}
            className="flex-1 h-12 text-base font-semibold bg-primary hover:bg-primary/90"
            size="lg"
          >
            <Sparkles className="w-4 h-4 mr-2" />
            Get Started
          </Button>
          <Button
            onClick={() => navigateTo('login')}
            variant="outline"
            className="flex-1 h-12 text-base font-semibold border-primary text-primary hover:bg-primary/10"
            size="lg"
          >
            Sign In
          </Button>
        </motion.div>
      </section>

      {/* Features Section */}
      <section className="px-4 sm:px-6 pb-8">
        <motion.h2
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="text-xl font-bold text-foreground mb-4"
        >
          Why DesignAR?
        </motion.h2>
        <div className="grid grid-cols-2 gap-3 sm:gap-4">
          {features.map((feature, index) => (
            <motion.div
              key={feature.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className="rounded-xl border border-border bg-card p-4 sm:p-5"
            >
              <div className={`w-10 h-10 rounded-lg ${feature.bg} flex items-center justify-center mb-3`}>
                <feature.icon className={`w-5 h-5 ${feature.color}`} />
              </div>
              <h3 className="font-semibold text-sm sm:text-base text-foreground">{feature.title}</h3>
              <p className="text-xs sm:text-sm text-muted-foreground mt-1">{feature.description}</p>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Showcase Section */}
      <section className="px-4 sm:px-6 pb-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="rounded-2xl overflow-hidden border border-border bg-card"
        >
          <img
            src="/furniture-catalog.png"
            alt="Furniture Catalog"
            className="w-full h-40 sm:h-56 object-cover"
          />
          <div className="p-4 sm:p-5">
            <h3 className="font-bold text-foreground text-lg">Extensive Catalog</h3>
            <p className="text-muted-foreground text-sm mt-1">
              Browse through 100+ curated furniture pieces across Living Room, Bedroom, Kitchen, Office, and Decor categories.
            </p>
          </div>
        </motion.div>
      </section>

      {/* Bottom CTA */}
      <section className="px-4 sm:px-6 pb-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="rounded-2xl bg-gradient-to-r from-teal-600 to-emerald-600 p-6 sm:p-8 text-center"
        >
          <h3 className="text-xl font-bold text-white">Ready to Design?</h3>
          <p className="text-white/80 text-sm mt-2">
            Start creating your dream space today
          </p>
          <Button
            onClick={() => navigateTo('signup')}
            className="mt-4 bg-white text-teal-700 hover:bg-white/90 font-semibold"
            size="lg"
          >
            <Share2 className="w-4 h-4 mr-2" />
            Start for Free
          </Button>
        </motion.div>
      </section>

      {/* Footer */}
      <footer className="px-4 sm:px-6 py-4 text-center text-xs text-muted-foreground border-t border-border">
        <div className="flex items-center justify-center gap-2 mb-1">
          <span>&copy; 2026 DesignAR.</span>
          <span className="text-[10px] font-medium text-primary bg-primary/10 px-1.5 py-0.5 rounded-full">v2.0.0</span>
        </div>
        <p>All rights reserved.</p>
      </footer>
    </div>
  );
}
