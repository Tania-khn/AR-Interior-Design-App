'use client';

import { motion } from 'framer-motion';
import { useAppStore } from '@/stores/app-store';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { ArrowLeft, Shield } from 'lucide-react';

const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: { staggerChildren: 0.05 },
  },
};

const item = {
  hidden: { opacity: 0, y: 10 },
  show: { opacity: 1, y: 0 },
};

export default function PrivacyPolicyPage() {
  const navigateTo = useAppStore((s) => s.navigateTo);

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <motion.header
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        className="sticky top-0 z-40 bg-background/95 backdrop-blur-md border-b border-border"
      >
        <div className="flex items-center px-4 py-3 gap-3">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => navigateTo('settings')}
            className="w-9 h-9"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <h1 className="text-lg font-bold text-foreground">Privacy Policy</h1>
        </div>
      </motion.header>

      <motion.div
        variants={container}
        initial="hidden"
        animate="show"
        className="px-4 sm:px-6 pt-4 pb-10"
      >
        <motion.div variants={item} className="mb-4">
          <div className="flex items-center gap-2 mb-1">
            <Shield className="w-5 h-5 text-primary" />
            <h2 className="text-base font-bold text-foreground">Privacy Policy</h2>
          </div>
          <p className="text-xs text-muted-foreground">Last updated: March 2026</p>
        </motion.div>

        {[
          {
            title: '1. Information We Collect',
            content: `We collect information you provide directly to us, such as when you create an account, save designs, use our AR features, or contact us for support. This includes:\n\n• Account Information: Your name, email address, and password when you sign up.\n• Design Data: Room layouts, furniture placements, and design preferences you save within the app.\n• Usage Data: Information about how you use DesignAR, including features accessed, time spent, and interaction patterns.\n• Device Information: Device type, operating system, and screen resolution to optimize your experience.`,
          },
          {
            title: '2. How We Use Your Information',
            content: `We use the information we collect to:\n\n• Provide, maintain, and improve our AR interior design services.\n• Personalize your experience and provide tailored design recommendations.\n• Send you notifications about saved designs and new features (based on your preferences).\n• Respond to your comments, questions, and support requests.\n• Monitor and analyze trends, usage, and activities in connection with our services.\n• Detect, investigate, and prevent fraudulent transactions and abuse.`,
          },
          {
            title: '3. Information Sharing',
            content: `We do not sell, trade, or otherwise transfer your personally identifiable information to outside parties. This does not include trusted third parties who assist us in operating our website, conducting our business, or servicing you, so long as those parties agree to keep this information confidential.\n\nWe may also release your information when we believe release is appropriate to comply with the law, enforce our site policies, or protect ours or others' rights, property, or safety.`,
          },
          {
            title: '4. Data Storage & Security',
            content: `Your design data and personal information are stored securely using industry-standard encryption. We implement a variety of security measures including:\n\n• Encrypted data transmission (SSL/TLS)\n• Secure password hashing\n• Regular security audits\n• Access controls and authentication\n\nHowever, no method of transmission over the Internet is 100% secure, and we cannot guarantee absolute security.`,
          },
          {
            title: '5. AR Camera & Permissions',
            content: `DesignAR uses your device's camera for augmented reality features. Camera access is only active while you are using the AR design view and is never recorded or stored. We do not capture, save, or transmit any camera imagery.\n\nYou can revoke camera permission at any time through your device settings, though this will limit AR functionality.`,
          },
          {
            title: '6. Your Rights',
            content: `You have the right to:\n\n• Access the personal data we hold about you.\n• Request correction of any inaccurate data.\n• Request deletion of your account and associated data.\n• Opt out of marketing communications at any time.\n• Export your design data in a portable format.\n\nTo exercise any of these rights, please contact us using the information provided in the Settings section of the app.`,
          },
          {
            title: '7. Children\'s Privacy',
            content: `Our services are not directed to individuals under the age of 13. We do not knowingly collect personal information from children under 13. If we become aware that a child under 13 has provided us with personal information, we take steps to delete such information.`,
          },
          {
            title: '8. Changes to This Policy',
            content: `We may update our Privacy Policy from time to time. We will notify you of any changes by posting the new Privacy Policy on this page and updating the "Last updated" date. You are advised to review this Privacy Policy periodically for any changes.`,
          },
          {
            title: '9. Contact Us',
            content: `If you have any questions about this Privacy Policy, please contact us:\n\n• Email: support@designar.app\n• Phone: +1 (555) 123-4567\n• Website: www.designar.app\n• Address: 123 Design Street, Creative City, CA 90210`,
          },
        ].map((section, index) => (
          <motion.div key={index} variants={item} className="mb-4">
            <Card className="border-border">
              <CardContent className="p-4">
                <h3 className="text-sm font-semibold text-foreground mb-2">
                  {section.title}
                </h3>
                {section.content.split('\n').map((paragraph, pIndex) => (
                  <p
                    key={pIndex}
                    className="text-xs leading-relaxed text-muted-foreground mb-1"
                  >
                    {paragraph}
                  </p>
                ))}
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </motion.div>
    </div>
  );
}
