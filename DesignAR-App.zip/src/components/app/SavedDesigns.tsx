'use client';

import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useAppStore } from '@/stores/app-store';
import { useDesignStore } from '@/stores/design-store';
import ThemeToggle from './ThemeToggle';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import {
  FolderOpen,
  Trash2,
  Pencil,
  Box,
  Search,
  MoreVertical,
  Sparkles,
} from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { toast } from 'sonner';

const roomEmojis: Record<string, string> = {
  'Living Room': '🛋️',
  Bedroom: '🛏️',
  Kitchen: '🍳',
  Office: '💼',
};

export default function SavedDesigns() {
  const navigateTo = useAppStore((s) => s.navigateTo);
  const savedDesigns = useDesignStore((s) => s.savedDesigns);
  const loadSavedDesigns = useDesignStore((s) => s.loadSavedDesigns);
  const loadDesign = useDesignStore((s) => s.loadDesign);
  const deleteDesign = useDesignStore((s) => s.deleteDesign);
  const renameDesign = useDesignStore((s) => s.renameDesign);
  const [searchQuery, setSearchQuery] = useState('');
  const [renameId, setRenameId] = useState<string | null>(null);
  const [renameValue, setRenameValue] = useState('');
  const [deleteId, setDeleteId] = useState<string | null>(null);

  useEffect(() => {
    loadSavedDesigns();
  }, [loadSavedDesigns]);

  const filteredDesigns = savedDesigns.filter(
    (d) =>
      d.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      d.roomType.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleOpen = (id: string) => {
    loadDesign(id);
    navigateTo('ar-view');
  };

  const handleRename = () => {
    if (renameId && renameValue.trim()) {
      renameDesign(renameId, renameValue.trim());
      toast.success('Design renamed');
      setRenameId(null);
      setRenameValue('');
    }
  };

  const handleDelete = () => {
    if (deleteId) {
      deleteDesign(deleteId);
      toast.success('Design deleted');
      setDeleteId(null);
    }
  };

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    });
  };

  return (
    <div className="min-h-screen bg-background pb-20">
      {/* Header */}
      <motion.header
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        className="sticky top-0 z-40 bg-background/95 backdrop-blur-md border-b border-border"
      >
        <div className="flex items-center justify-between px-4 py-3">
          <h1 className="text-lg font-bold text-foreground">Saved Designs</h1>
          <ThemeToggle />
        </div>

        {/* Search */}
        <div className="px-4 pb-3">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search designs..."
              className="pl-9 h-10 bg-muted/50"
            />
          </div>
        </div>
      </motion.header>

      {/* Designs Grid */}
      <div className="px-4 pt-4">
        <AnimatePresence>
          {filteredDesigns.length > 0 ? (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="grid grid-cols-2 gap-3"
            >
              {filteredDesigns.map((design, index) => (
                <motion.div
                  key={design.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.9 }}
                  transition={{ delay: index * 0.05 }}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  <Card className="border-border overflow-hidden">
                    {/* Thumbnail */}
                    <div
                      className="h-28 sm:h-32 flex items-center justify-center bg-gradient-to-br from-teal-100 to-emerald-100 dark:from-teal-900/30 dark:to-emerald-900/30 relative cursor-pointer"
                      onClick={() => handleOpen(design.id)}
                    >
                      <span className="text-4xl">
                        {roomEmojis[design.roomType] || '🏠'}
                      </span>

                      {/* Items count badge */}
                      <Badge className="absolute top-2 left-2 text-[10px] bg-card/80 backdrop-blur-sm">
                        {design.items.length} items
                      </Badge>

                      {/* Menu */}
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="absolute top-1 right-1 w-7 h-7"
                            onClick={(e) => e.stopPropagation()}
                          >
                            <MoreVertical className="w-3.5 h-3.5" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem
                            onClick={(e) => {
                              e.stopPropagation();
                              setRenameId(design.id);
                              setRenameValue(design.name);
                            }}
                          >
                            <Pencil className="w-3.5 h-3.5 mr-2" />
                            Rename
                          </DropdownMenuItem>
                          <DropdownMenuItem
                            className="text-destructive"
                            onClick={(e) => {
                              e.stopPropagation();
                              setDeleteId(design.id);
                            }}
                          >
                            <Trash2 className="w-3.5 h-3.5 mr-2" />
                            Delete
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </div>

                    <CardContent className="p-3">
                      <h3 className="font-semibold text-sm text-foreground truncate">
                        {design.name}
                      </h3>
                      <div className="flex items-center gap-2 mt-1">
                        <Badge variant="secondary" className="text-[10px] px-1.5 py-0">
                          {design.roomType}
                        </Badge>
                        <span className="text-[10px] text-muted-foreground">
                          {formatDate(design.createdAt)}
                        </span>
                      </div>

                      <Button
                        size="sm"
                        className="w-full mt-2 h-8 text-xs bg-primary hover:bg-primary/90"
                        onClick={() => handleOpen(design.id)}
                      >
                        <Box className="w-3 h-3 mr-1" />
                        Open in AR
                      </Button>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </motion.div>
          ) : (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="flex flex-col items-center justify-center py-16"
            >
              <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center mb-4">
                <FolderOpen className="w-8 h-8 text-muted-foreground" />
              </div>
              <h3 className="font-bold text-foreground text-lg">
                {searchQuery ? 'No results found' : 'No saved designs'}
              </h3>
              <p className="text-sm text-muted-foreground mt-1 text-center max-w-[250px]">
                {searchQuery
                  ? 'Try a different search term'
                  : 'Start designing rooms and save them here for later'}
              </p>
              {!searchQuery && (
                <Button
                  onClick={() => navigateTo('ar-view')}
                  className="mt-4 bg-primary hover:bg-primary/90"
                  size="sm"
                >
                  <Sparkles className="w-4 h-4 mr-2" />
                  Start Designing
                </Button>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Rename Dialog */}
      <Dialog open={!!renameId} onOpenChange={() => setRenameId(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Rename Design</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 pt-2">
            <Input
              value={renameValue}
              onChange={(e) => setRenameValue(e.target.value)}
              placeholder="Design name"
              onKeyDown={(e) => e.key === 'Enter' && handleRename()}
            />
            <Button
              onClick={handleRename}
              className="w-full bg-primary hover:bg-primary/90"
            >
              Save
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation */}
      <Dialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Delete Design</DialogTitle>
          </DialogHeader>
          <p className="text-sm text-muted-foreground">
            Are you sure you want to delete this design? This action cannot be undone.
          </p>
          <div className="flex gap-2 mt-4">
            <Button
              variant="outline"
              className="flex-1"
              onClick={() => setDeleteId(null)}
            >
              Cancel
            </Button>
            <Button
              variant="destructive"
              className="flex-1"
              onClick={handleDelete}
            >
              Delete
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
