'use client';

import { motion } from 'framer-motion';
import { useAppStore } from '@/stores/app-store';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { ArrowLeft, FileText } from 'lucide-react';

const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: { staggerChildren: 0.05 },
  },
};

const item = {
  hidden: { opacity: 0, y: 10 },
  show: { opacity: 1, y: 0 },
};

export default function TermsConditionsPage() {
  const navigateTo = useAppStore((s) => s.navigateTo);

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <motion.header
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        className="sticky top-0 z-40 bg-background/95 backdrop-blur-md border-b border-border"
      >
        <div className="flex items-center px-4 py-3 gap-3">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => navigateTo('settings')}
            className="w-9 h-9"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <h1 className="text-lg font-bold text-foreground">Terms & Conditions</h1>
        </div>
      </motion.header>

      <motion.div
        variants={container}
        initial="hidden"
        animate="show"
        className="px-4 sm:px-6 pt-4 pb-10"
      >
        <motion.div variants={item} className="mb-4">
          <div className="flex items-center gap-2 mb-1">
            <FileText className="w-5 h-5 text-primary" />
            <h2 className="text-base font-bold text-foreground">Terms & Conditions</h2>
          </div>
          <p className="text-xs text-muted-foreground">Last updated: March 2026</p>
        </motion.div>

        {[
          {
            title: '1. Acceptance of Terms',
            content: `By downloading, installing, or using the DesignAR mobile application ("App"), you agree to be bound by these Terms and Conditions. If you do not agree to these terms, please do not use the App. These terms constitute a legally binding agreement between you and DesignAR.`,
          },
          {
            title: '2. Description of Service',
            content: `DesignAR provides an augmented reality-based interior design platform that allows users to visualize furniture and decor in their physical space using their device's camera. The App includes features for browsing furniture catalogs, placing virtual items in AR, saving designs, and accessing design tips and recommendations.`,
          },
          {
            title: '3. User Accounts',
            content: `You must create an account to access certain features of the App. You are responsible for maintaining the confidentiality of your account credentials and for all activities that occur under your account. You agree to:\n\n• Provide accurate and complete registration information.\n• Update your information to keep it accurate and current.\n• Notify us immediately of any unauthorized use of your account.\n• Not share your account credentials with any third party.`,
          },
          {
            title: '4. Acceptable Use',
            content: `You agree not to:\n\n• Use the App for any unlawful purpose or in violation of any applicable laws.\n• Attempt to gain unauthorized access to any portion of the App or its related systems.\n• Use the App to transmit any harmful, threatening, or objectionable content.\n• Reverse-engineer, decompile, or disassemble any part of the App.\n• Interfere with or disrupt the App's servers or networks.\n• Use automated means to access the App for any purpose without our express permission.`,
          },
          {
            title: '5. Intellectual Property',
            content: `All content, features, and functionality of the App — including but not limited to text, graphics, logos, icons, images, audio clips, digital downloads, and data compilations — are the exclusive property of DesignAR or its content suppliers and are protected by international copyright, trademark, and other intellectual property laws.\n\nYour saved designs remain your property. However, by using the App, you grant DesignAR a limited, non-exclusive license to process and store your design data for the purpose of providing the service.`,
          },
          {
            title: '6. AR Feature Disclaimer',
            content: `The augmented reality features of DesignAR are provided for visualization and planning purposes only. AR measurements and representations may not be perfectly accurate due to device limitations, lighting conditions, and environmental factors. DesignAR is not responsible for:\n\n• Measurement inaccuracies that may affect furniture purchases.\n• Visual discrepancies between AR previews and actual products.\n• Any decisions made based solely on AR visualizations without physical verification.`,
          },
          {
            title: '7. Limitation of Liability',
            content: `To the fullest extent permitted by applicable law, DesignAR shall not be liable for any indirect, incidental, special, consequential, or punitive damages, or any loss of profits or revenues, whether incurred directly or indirectly, or any loss of data, use, goodwill, or other intangible losses resulting from your use of the App.`,
          },
          {
            title: '8. Termination',
            content: `We may terminate or suspend your account and access to the App at our sole discretion, without prior notice, for conduct that we believe violates these Terms or is harmful to other users, us, or third parties, or for any other reason. Upon termination, your right to use the App will immediately cease.`,
          },
          {
            title: '9. Changes to Terms',
            content: `We reserve the right to modify these Terms at any time. We will provide notice of significant changes by posting the updated Terms on this page with a new "Last updated" date. Your continued use of the App after such changes constitutes your acceptance of the new Terms.`,
          },
          {
            title: '10. Contact',
            content: `If you have questions about these Terms and Conditions, please contact us:\n\n• Email: support@designar.app\n• Phone: +1 (555) 123-4567\n• Website: www.designar.app\n• Address: 123 Design Street, Creative City, CA 90210`,
          },
        ].map((section, index) => (
          <motion.div key={index} variants={item} className="mb-4">
            <Card className="border-border">
              <CardContent className="p-4">
                <h3 className="text-sm font-semibold text-foreground mb-2">
                  {section.title}
                </h3>
                {section.content.split('\n').map((paragraph, pIndex) => (
                  <p
                    key={pIndex}
                    className="text-xs leading-relaxed text-muted-foreground mb-1"
                  >
                    {paragraph}
                  </p>
                ))}
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </motion.div>
    </div>
  );
}
