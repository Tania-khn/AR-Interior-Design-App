'use client';

import { motion } from 'framer-motion';
import { useAppStore } from '@/stores/app-store';
import { useAuthStore } from '@/stores/auth-store';
import { useDesignStore } from '@/stores/design-store';
import ThemeToggle from './ThemeToggle';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import {
  User,
  Mail,
  Calendar,
  LogOut,
  Settings,
  Box,
  Armchair,
  Home,
  ChevronRight,
} from 'lucide-react';
import { toast } from 'sonner';

const container = {
  hidden: { opacity: 0 },
  show: {
    opacity: 1,
    transition: { staggerChildren: 0.08 },
  },
};

const item = {
  hidden: { opacity: 0, y: 10 },
  show: { opacity: 1, y: 0 },
};

export default function ProfilePage() {
  const navigateTo = useAppStore((s) => s.navigateTo);
  const user = useAuthStore((s) => s.user);
  const logout = useAuthStore((s) => s.logout);
  const savedDesigns = useDesignStore((s) => s.savedDesigns);
  const currentItems = useDesignStore((s) => s.currentItems);

  const totalItemsPlaced = savedDesigns.reduce((acc, d) => acc + d.items.length, 0) + currentItems.length;
  const roomTypes = new Set(savedDesigns.map((d) => d.roomType)).size;

  const handleLogout = () => {
    logout();
    toast.success('Logged out successfully');
    navigateTo('landing');
  };

  const initials = user?.fullName
    ? user.fullName
        .split(' ')
        .map((n) => n[0])
        .join('')
        .toUpperCase()
        .slice(0, 2)
    : 'U';

  const memberSince = user?.createdAt
    ? new Date(user.createdAt).toLocaleDateString('en-US', {
        month: 'long',
        year: 'numeric',
      })
    : 'Unknown';

  return (
    <div className="min-h-screen bg-background pb-20">
      {/* Header */}
      <motion.header
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        className="sticky top-0 z-40 bg-background/95 backdrop-blur-md border-b border-border"
      >
        <div className="flex items-center justify-between px-4 py-3">
          <h1 className="text-lg font-bold text-foreground">Profile</h1>
          <ThemeToggle />
        </div>
      </motion.header>

      <motion.div
        variants={container}
        initial="hidden"
        animate="show"
        className="px-4 sm:px-6 pt-6 space-y-6"
      >
        {/* Profile Card */}
        <motion.div variants={item}>
          <Card className="border-border">
            <CardContent className="p-6 flex flex-col items-center text-center">
              {/* Avatar */}
              <div className="w-20 h-20 rounded-full bg-gradient-to-br from-teal-500 to-emerald-600 flex items-center justify-center text-white text-2xl font-bold shadow-lg">
                {initials}
              </div>

              <h2 className="text-xl font-bold text-foreground mt-4">
                {user?.fullName || 'User'}
              </h2>
              <p className="text-sm text-muted-foreground mt-1">{user?.email}</p>

              <div className="flex items-center gap-1 mt-2 text-xs text-muted-foreground">
                <Calendar className="w-3 h-3" />
                <span>Member since {memberSince}</span>
              </div>

              <Button
                variant="outline"
                className="mt-4 border-primary text-primary hover:bg-primary/10"
                size="sm"
                onClick={() => toast.info('Profile editing coming soon!')}
              >
                <User className="w-4 h-4 mr-2" />
                Edit Profile
              </Button>
            </CardContent>
          </Card>
        </motion.div>

        {/* Stats */}
        <motion.div variants={item}>
          <div className="grid grid-cols-3 gap-3">
            <Card className="border-border">
              <CardContent className="p-4 text-center">
                <div className="w-10 h-10 rounded-lg bg-teal-100 dark:bg-teal-900/30 flex items-center justify-center mx-auto mb-2">
                  <Box className="w-5 h-5 text-teal-600 dark:text-teal-400" />
                </div>
                <p className="text-2xl font-bold text-foreground">{savedDesigns.length}</p>
                <p className="text-xs text-muted-foreground">Designs</p>
              </CardContent>
            </Card>
            <Card className="border-border">
              <CardContent className="p-4 text-center">
                <div className="w-10 h-10 rounded-lg bg-amber-100 dark:bg-amber-900/30 flex items-center justify-center mx-auto mb-2">
                  <Armchair className="w-5 h-5 text-amber-600 dark:text-amber-400" />
                </div>
                <p className="text-2xl font-bold text-foreground">{totalItemsPlaced}</p>
                <p className="text-xs text-muted-foreground">Items Placed</p>
              </CardContent>
            </Card>
            <Card className="border-border">
              <CardContent className="p-4 text-center">
                <div className="w-10 h-10 rounded-lg bg-emerald-100 dark:bg-emerald-900/30 flex items-center justify-center mx-auto mb-2">
                  <Home className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
                </div>
                <p className="text-2xl font-bold text-foreground">{roomTypes}</p>
                <p className="text-xs text-muted-foreground">Room Types</p>
              </CardContent>
            </Card>
          </div>
        </motion.div>

        {/* Menu Items */}
        <motion.div variants={item}>
          <Card className="border-border">
            <CardContent className="p-0">
              <button
                onClick={() => navigateTo('settings')}
                className="flex items-center justify-between w-full px-4 py-3.5 hover:bg-muted/50 transition-colors"
              >
                <div className="flex items-center gap-3">
                  <Settings className="w-5 h-5 text-muted-foreground" />
                  <span className="text-sm font-medium text-foreground">Settings</span>
                </div>
                <ChevronRight className="w-4 h-4 text-muted-foreground" />
              </button>

              <Separator />

              <button
                onClick={() => navigateTo('saved')}
                className="flex items-center justify-between w-full px-4 py-3.5 hover:bg-muted/50 transition-colors"
              >
                <div className="flex items-center gap-3">
                  <Box className="w-5 h-5 text-muted-foreground" />
                  <span className="text-sm font-medium text-foreground">My Designs</span>
                </div>
                <ChevronRight className="w-4 h-4 text-muted-foreground" />
              </button>

              <Separator />

              <button
                onClick={() => navigateTo('catalog')}
                className="flex items-center justify-between w-full px-4 py-3.5 hover:bg-muted/50 transition-colors"
              >
                <div className="flex items-center gap-3">
                  <Armchair className="w-5 h-5 text-muted-foreground" />
                  <span className="text-sm font-medium text-foreground">Browse Catalog</span>
                </div>
                <ChevronRight className="w-4 h-4 text-muted-foreground" />
              </button>

              <Separator />

              <button
                onClick={() => navigateTo('settings')}
                className="flex items-center justify-between w-full px-4 py-3.5 hover:bg-muted/50 transition-colors"
              >
                <div className="flex items-center gap-3">
                  <Mail className="w-5 h-5 text-muted-foreground" />
                  <span className="text-sm font-medium text-foreground">Contact Support</span>
                </div>
                <ChevronRight className="w-4 h-4 text-muted-foreground" />
              </button>
            </CardContent>
          </Card>
        </motion.div>

        {/* Logout */}
        <motion.div variants={item}>
          <Button
            variant="outline"
            className="w-full border-destructive text-destructive hover:bg-destructive/10"
            onClick={handleLogout}
          >
            <LogOut className="w-4 h-4 mr-2" />
            Log Out
          </Button>
        </motion.div>

        {/* App Version */}
        <motion.div variants={item} className="text-center pt-2">
          <span className="text-[10px] font-medium text-primary bg-primary/10 px-2.5 py-1 rounded-full">
            DesignAR v2.0.0
          </span>
        </motion.div>
      </motion.div>
    </div>
  );
}
