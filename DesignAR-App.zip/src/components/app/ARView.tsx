'use client';

import { useState, useCallback, useRef, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useAppStore } from '@/stores/app-store';
import { useDesignStore, type PlacedFurniture } from '@/stores/design-store';
import { furnitureItems, categories, categoryEmojis, type FurnitureCategory } from '@/lib/furniture-data';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetDescription,
} from '@/components/ui/sheet';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  ArrowLeft,
  Camera,
  CameraOff,
  Move,
  RotateCw,
  Maximize2,
  Trash2,
  MousePointer2,
  Grid3X3,
  Save,
  Undo2,
  Crosshair,
  ScanLine,
  Home,
  BedDouble,
  CookingPot,
  Briefcase,
  Palette,
  Minus,
  Plus,
  X,
  Search,
  ShoppingBag,
  Check,
} from 'lucide-react';
import { toast } from 'sonner';

type Tool = 'select' | 'move' | 'rotate' | 'scale' | 'delete';

const tools: { id: Tool; icon: typeof MousePointer2; label: string }[] = [
  { id: 'select', icon: MousePointer2, label: 'Select' },
  { id: 'move', icon: Move, label: 'Move' },
  { id: 'rotate', icon: RotateCw, label: 'Rotate' },
  { id: 'scale', icon: Maximize2, label: 'Scale' },
  { id: 'delete', icon: Trash2, label: 'Delete' },
];

type RoomType = 'Living Room' | 'Bedroom' | 'Kitchen' | 'Office';

const roomImages: Record<RoomType, string> = {
  'Living Room': '/room-living.png',
  'Bedroom': '/room-bedroom.png',
  'Kitchen': '/room-kitchen.png',
  'Office': '/room-office.png',
};

const roomIcons: Record<RoomType, typeof Home> = {
  'Living Room': Home,
  'Bedroom': BedDouble,
  'Kitchen': CookingPot,
  'Office': Briefcase,
};

const roomColorGrads: Record<RoomType, string> = {
  'Living Room': 'from-teal-500/80 to-emerald-600/80',
  'Bedroom': 'from-indigo-500/80 to-purple-600/80',
  'Kitchen': 'from-amber-500/80 to-orange-600/80',
  'Office': 'from-slate-500/80 to-zinc-600/80',
};

// Self-contained scan overlay with its own timer lifecycle
function ScanOverlay() {
  const [visible, setVisible] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => setVisible(false), 3000);
    return () => clearTimeout(timer);
  }, []);

  if (!visible) return null;

  return (
    <div className="absolute inset-0 pointer-events-none z-10 overflow-hidden">
      <div className="scan-line absolute left-0 right-0 h-0.5 bg-primary/50" />
      <div className="absolute top-4 left-4 w-8 h-8 border-l-2 border-t-2 border-primary/70 ar-corner-pulse" />
      <div className="absolute top-4 right-4 w-8 h-8 border-r-2 border-t-2 border-primary/70 ar-corner-pulse" />
      <div className="absolute bottom-4 left-4 w-8 h-8 border-l-2 border-b-2 border-primary/70 ar-corner-pulse" />
      <div className="absolute bottom-4 right-4 w-8 h-8 border-r-2 border-b-2 border-primary/70 ar-corner-pulse" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2">
        <div className="w-8 h-8 border border-primary/40 rounded-full flex items-center justify-center">
          <div className="w-1.5 h-1.5 bg-primary/60 rounded-full" />
        </div>
      </div>
      <div className="absolute top-4 left-1/2 -translate-x-1/2">
        <Badge className="bg-primary/80 text-primary-foreground text-[10px] animate-pulse">
          <ScanLine className="w-3 h-3 mr-1" />
          Detecting surfaces...
        </Badge>
      </div>
    </div>
  );
}

// Individual furniture item rendered with pointer events for drag
function FurnitureItem({
  placed,
  isSelected,
  isCameraMode,
  activeTool,
  onSelect,
  onDragMove,
  onDragEnd,
  onRotate,
  onScaleUp,
  onScaleDown,
  onDelete,
}: {
  placed: PlacedFurniture;
  isSelected: boolean;
  isCameraMode: boolean;
  activeTool: Tool;
  onSelect: (id: string) => void;
  onDragMove: (id: string, clientX: number, clientY: number) => void;
  onDragEnd: () => void;
  onRotate: (id: string) => void;
  onScaleUp: (id: string) => void;
  onScaleDown: (id: string) => void;
  onDelete: (id: string) => void;
}) {
  const dragRef = useRef<{ startX: number; startY: number; origX: number; origY: number; dragging: boolean }>({
    startX: 0, startY: 0, origX: 0, origY: 0, dragging: false,
  });
  // Use state to track dragging for re-render (ref won't trigger re-render for style changes)
  const [isDragging, setIsDragging] = useState(false);

  const handlePointerDown = (e: React.PointerEvent) => {
    // Always select on first click
    if (!isSelected) {
      onSelect(placed.id);
      return;
    }

    // If already selected, handle tool actions
    if (activeTool === 'move' && isSelected) {
      dragRef.current = {
        startX: e.clientX,
        startY: e.clientY,
        origX: placed.x,
        origY: placed.y,
        dragging: true,
      };
      setIsDragging(true);
      (e.target as HTMLElement).setPointerCapture(e.pointerId);
    } else if (activeTool === 'rotate' && isSelected) {
      onRotate(placed.id);
    } else if (activeTool === 'scale' && isSelected) {
      onScaleUp(placed.id);
    } else if (activeTool === 'delete') {
      onDelete(placed.id);
    }
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!dragRef.current.dragging) return;
    onDragMove(placed.id, e.clientX, e.clientY);
  };

  const handlePointerUp = () => {
    if (dragRef.current.dragging) {
      dragRef.current.dragging = false;
      setIsDragging(false);
      onDragEnd();
    }
  };

  return (
    <div
      className={`absolute cursor-pointer select-none z-20 ${
        isSelected ? 'z-30' : ''
      }`}
      style={{
        left: `${placed.x}%`,
        top: `${placed.y}%`,
        transform: `translate(-50%, -50%) rotate(${placed.rotation}deg) scale(${placed.scale})`,
        transition: isDragging ? 'none' : 'transform 0.15s ease-out',
      }}
      onPointerDown={handlePointerDown}
      onPointerMove={handlePointerMove}
      onPointerUp={handlePointerUp}
    >
      <div
        className={`relative flex flex-col items-center justify-center rounded-xl p-2 ${
          isSelected
            ? isCameraMode
              ? 'ring-2 ring-primary shadow-lg backdrop-blur-sm'
              : 'ring-2 ring-primary shadow-lg'
            : isCameraMode
              ? 'bg-black/50 backdrop-blur-md shadow-lg ring-1 ring-white/20'
              : 'bg-card/80 backdrop-blur-sm shadow-md'
        }`}
        style={{
          minWidth: '64px',
          minHeight: '64px',
          borderColor: placed.color,
          borderWidth: isSelected ? '0px' : '2px',
          borderStyle: 'solid',
          backgroundColor: isSelected
            ? isCameraMode
              ? `${placed.color}55`
              : `${placed.color}33`
            : undefined,
        }}
      >
        <span className="text-3xl sm:text-4xl drop-shadow-lg">{placed.emoji}</span>
        <span className={`text-[9px] font-medium mt-0.5 truncate max-w-[64px] ${
          isCameraMode ? 'text-white' : 'text-foreground'
        }`}>
          {placed.name}
        </span>

        {/* Selected indicator */}
        {isSelected && (
          <div className="absolute -top-1 -right-1 w-5 h-5 bg-primary rounded-full flex items-center justify-center shadow-lg">
            <div className="w-2 h-2 bg-primary-foreground rounded-full" />
          </div>
        )}

        {/* Quick action buttons when selected */}
        {isSelected && (
          <div className="absolute -top-9 left-1/2 -translate-x-1/2 flex items-center gap-0.5 bg-card/95 backdrop-blur-sm rounded-full px-1 py-0.5 shadow-lg border border-border">
            <button
              className="w-6 h-6 rounded-full bg-card shadow-sm border border-border flex items-center justify-center hover:bg-muted active:scale-90 transition-transform"
              onPointerDown={(e) => e.stopPropagation()}
              onClick={(e) => { e.stopPropagation(); onScaleDown(placed.id); }}
              title="Scale Down"
            >
              <Minus className="w-3 h-3" />
            </button>
            <button
              className="w-6 h-6 rounded-full bg-primary/20 shadow-sm border border-primary/40 flex items-center justify-center hover:bg-primary/30 active:scale-90 transition-transform"
              onPointerDown={(e) => e.stopPropagation()}
              onClick={(e) => { e.stopPropagation(); onRotate(placed.id); }}
              title="Rotate 45°"
            >
              <RotateCw className="w-3 h-3 text-primary" />
            </button>
            <button
              className="w-6 h-6 rounded-full bg-card shadow-sm border border-border flex items-center justify-center hover:bg-muted active:scale-90 transition-transform"
              onPointerDown={(e) => e.stopPropagation()}
              onClick={(e) => { e.stopPropagation(); onScaleUp(placed.id); }}
              title="Scale Up"
            >
              <Plus className="w-3 h-3" />
            </button>
            <button
              className="w-6 h-6 rounded-full bg-destructive/20 shadow-sm border border-destructive/40 flex items-center justify-center hover:bg-destructive/30 active:scale-90 transition-transform"
              onPointerDown={(e) => e.stopPropagation()}
              onClick={(e) => { e.stopPropagation(); onDelete(placed.id); }}
              title="Delete"
            >
              <Trash2 className="w-3 h-3 text-destructive" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

export default function ARView() {
  const navigateTo = useAppStore((s) => s.navigateTo);
  const selectedFurnitureId = useAppStore((s) => s.selectedFurnitureId);
  const setSelectedFurniture = useAppStore((s) => s.setSelectedFurniture);
  const currentItems = useDesignStore((s) => s.currentItems);
  const addItem = useDesignStore((s) => s.addItem);
  const updateItem = useDesignStore((s) => s.updateItem);
  const removeItem = useDesignStore((s) => s.removeItem);
  const selectItem = useDesignStore((s) => s.selectItem);
  const selectedItemId = useDesignStore((s) => s.selectedItemId);
  const saveDesign = useDesignStore((s) => s.saveDesign);
  const clearCurrentItems = useDesignStore((s) => s.clearCurrentItems);
  const arSettings = useDesignStore((s) => s.arSettings);
  const updateArSettings = useDesignStore((s) => s.updateArSettings);
  const loadSavedDesigns = useDesignStore((s) => s.loadSavedDesigns);

  // Load saved designs and AR settings from localStorage on mount
  useEffect(() => {
    loadSavedDesigns();
  }, [loadSavedDesigns]);

  const [activeTool, setActiveTool] = useState<Tool>('move');
  const [showSaveDialog, setShowSaveDialog] = useState(false);
  const [designName, setDesignName] = useState('');
  const [roomType, setRoomType] = useState<RoomType>('Living Room');
  const [isCameraMode, setIsCameraMode] = useState(true);
  const [showRoomSelector, setShowRoomSelector] = useState(false);
  const [scanKey, setScanKey] = useState(0);
  const [showQuickAdd, setShowQuickAdd] = useState(false);
  const [quickAddSearch, setQuickAddSearch] = useState('');
  const [quickAddCategory, setQuickAddCategory] = useState<FurnitureCategory | 'All'>('All');
  const [recentlyAdded, setRecentlyAdded] = useState<string[]>([]);
  const roomRef = useRef<HTMLDivElement>(null);

  // Handle furniture from catalog navigation
  // When coming from catalog, the item is already added (by FurnitureCatalog)
  // selectedFurnitureId now holds the placed item's ID - just select it
  useEffect(() => {
    if (selectedFurnitureId) {
      // Check if this item already exists in currentItems (added by catalog)
      const existingItem = currentItems.find((i) => i.id === selectedFurnitureId);
      if (existingItem) {
        // Item was already added by catalog, just select it
        selectItem(selectedFurnitureId);
        setSelectedFurniture(null);
        toast.success(`${existingItem.name} added to room`);
      } else {
        // Fallback: item wasn't added yet (old flow), add it now
        const furniture = furnitureItems.find((f) => f.id === selectedFurnitureId);
        if (furniture) {
          const newItem: PlacedFurniture = {
            id: crypto.randomUUID(),
            furnitureId: furniture.id,
            name: furniture.name,
            emoji: furniture.emoji,
            x: 40 + Math.random() * 20,
            y: 40 + Math.random() * 20,
            rotation: 0,
            scale: 1,
            color: furniture.color,
            colors: furniture.colors,
          };
          addItem(newItem);
          selectItem(newItem.id);
          setSelectedFurniture(null);
          toast.success(`${furniture.name} added to room`);
        }
      }
    }
  }, [selectedFurnitureId, currentItems, addItem, setSelectedFurniture, selectItem]);

  const selectedItem = currentItems.find((i) => i.id === selectedItemId);

  // Get available colors for selected item
  const selectedItemColors = useMemo(() => {
    if (!selectedItem) return [];
    if (selectedItem.colors && selectedItem.colors.length > 0) {
      return selectedItem.colors;
    }
    const furniture = furnitureItems.find((f) => f.id === selectedItem.furnitureId);
    return furniture?.colors || [selectedItem.color];
  }, [selectedItem]);

  // Quick add filtered items
  const quickAddFiltered = useMemo(() => {
    let items = furnitureItems;
    if (quickAddCategory !== 'All') {
      items = items.filter((i) => i.category === quickAddCategory);
    }
    if (quickAddSearch.trim()) {
      const lower = quickAddSearch.toLowerCase();
      items = items.filter(
        (i) => i.name.toLowerCase().includes(lower) || i.category.toLowerCase().includes(lower)
      );
    }
    return items;
  }, [quickAddSearch, quickAddCategory]);

  // Drag handling
  const handleDragMove = useCallback(
    (id: string, clientX: number, clientY: number) => {
      if (!roomRef.current) return;
      const rect = roomRef.current.getBoundingClientRect();
      const x = ((clientX - rect.left) / rect.width) * 100;
      const y = ((clientY - rect.top) / rect.height) * 100;
      const clampedX = Math.max(5, Math.min(95, x));
      const clampedY = Math.max(10, Math.min(90, y));
      updateItem(id, { x: clampedX, y: clampedY });
    },
    [updateItem]
  );

  const handleDragEnd = useCallback(() => {
    // Just end the drag, position already saved
  }, []);

  // Quick actions on furniture
  const handleRotate = useCallback(
    (id: string) => {
      const item = currentItems.find((i) => i.id === id);
      if (item) {
        const newRotation = (item.rotation + 45) % 360;
        updateItem(id, { rotation: newRotation });
      }
    },
    [currentItems, updateItem]
  );

  const handleScaleUp = useCallback(
    (id: string) => {
      const item = currentItems.find((i) => i.id === id);
      if (item && item.scale < 2.5) {
        updateItem(id, { scale: Math.min(2.5, +(item.scale + 0.15).toFixed(2)) });
      }
    },
    [currentItems, updateItem]
  );

  const handleScaleDown = useCallback(
    (id: string) => {
      const item = currentItems.find((i) => i.id === id);
      if (item && item.scale > 0.3) {
        updateItem(id, { scale: Math.max(0.3, +(item.scale - 0.15).toFixed(2)) });
      }
    },
    [currentItems, updateItem]
  );

  const handleDelete = useCallback(
    (id: string) => {
      const item = currentItems.find((i) => i.id === id);
      removeItem(id);
      if (item) {
        toast.success(`${item.name} removed`);
      }
    },
    [currentItems, removeItem]
  );

  const handleSelect = useCallback(
    (id: string) => {
      selectItem(id);
    },
    [selectItem]
  );

  // Quick add furniture from the bottom sheet
  const handleQuickAdd = useCallback(
    (furniture: typeof furnitureItems[0]) => {
      const newItem: PlacedFurniture = {
        id: crypto.randomUUID(),
        furnitureId: furniture.id,
        name: furniture.name,
        emoji: furniture.emoji,
        x: 30 + Math.random() * 40,
        y: 30 + Math.random() * 30,
        rotation: 0,
        scale: 1,
        color: furniture.color,
        colors: furniture.colors,
      };
      addItem(newItem);
      selectItem(newItem.id);
      setRecentlyAdded((prev) => [...prev, furniture.id]);
      toast.success(`${furniture.name} added to room`, { duration: 1500 });

      // Remove "recently added" indicator after 2s
      setTimeout(() => {
        setRecentlyAdded((prev) => prev.filter((id) => id !== furniture.id));
      }, 2000);
    },
    [addItem, selectItem]
  );

  const handleSave = () => {
    if (!designName.trim()) {
      toast.error('Please enter a design name');
      return;
    }
    if (currentItems.length === 0) {
      toast.error('Add furniture to the room first');
      return;
    }
    saveDesign(designName.trim(), roomType);
    toast.success('Design saved successfully! Find it in Saved Designs.');
    setShowSaveDialog(false);
    setDesignName('');
  };

  const handleClear = () => {
    if (currentItems.length === 0) return;
    clearCurrentItems();
    toast.success('Room cleared');
  };

  const toggleCamera = () => {
    const newMode = !isCameraMode;
    setIsCameraMode(newMode);
    if (newMode) {
      setScanKey((k) => k + 1);
      toast.success('AR Camera ON - Real Room View');
    } else {
      toast.success('3D View Mode');
    }
  };

  const switchRoom = (type: RoomType) => {
    setRoomType(type);
    setShowRoomSelector(false);
    if (isCameraMode) {
      setScanKey((k) => k + 1);
    }
    toast.success(`Switched to ${type}`);
  };

  const toggleGrid = () => {
    updateArSettings({ showGrid: !arSettings.showGrid });
  };

  const handleColorChange = (color: string) => {
    if (selectedItemId) {
      updateItem(selectedItemId, { color });
    }
  };

  // Handle rotation slider change
  const handleRotationChange = (value: number[]) => {
    if (selectedItemId) {
      updateItem(selectedItemId, { rotation: value[0] });
    }
  };

  // Handle scale slider change
  const handleScaleChange = (value: number[]) => {
    if (selectedItemId) {
      updateItem(selectedItemId, { scale: value[0] / 100 });
    }
  };

  return (
    <div className="h-screen bg-background flex flex-col overflow-hidden">
      {/* Top Bar */}
      <div className="flex items-center justify-between px-3 py-2 bg-card/95 backdrop-blur-md border-b border-border z-30">
        <Button
          variant="ghost"
          size="icon"
          onClick={() => navigateTo('dashboard')}
          className="w-9 h-9"
        >
          <ArrowLeft className="w-5 h-5" />
        </Button>
        <div className="flex items-center gap-2">
          <Badge
            variant="secondary"
            className={`text-xs ${isCameraMode ? 'bg-primary/20 text-primary' : ''}`}
          >
            <Crosshair className="w-3 h-3 mr-1" />
            {isCameraMode ? 'AR Camera' : '3D View'}
          </Badge>
          <Badge variant="outline" className="text-xs border-primary/40 text-primary">
            {roomType}
          </Badge>
          {currentItems.length > 0 && (
            <Badge variant="secondary" className="text-xs">
              {currentItems.length} item{currentItems.length !== 1 ? 's' : ''}
            </Badge>
          )}
        </div>
        <div className="flex items-center gap-1">
          <Button variant="ghost" size="icon" className="w-9 h-9" onClick={handleClear}>
            <Undo2 className="w-4 h-4" />
          </Button>
          <Button
            variant="ghost"
            size="icon"
            className="w-9 h-9"
            onClick={() => setShowSaveDialog(true)}
          >
            <Save className="w-4 h-4" />
          </Button>
        </div>
      </div>

      {/* AR Room View */}
      <div
        ref={roomRef}
        className="flex-1 relative overflow-hidden"
        onClick={() => {
          // Deselect when clicking empty area
          if (showRoomSelector) {
            setShowRoomSelector(false);
          }
        }}
      >
        {/* Room Background */}
        <AnimatePresence mode="wait">
          {isCameraMode ? (
            <motion.div
              key={`real-${roomType}`}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.5 }}
              className="absolute inset-0 z-[1]"
            >
              <img
                src={roomImages[roomType]}
                alt={`${roomType} interior`}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-black/5" />
            </motion.div>
          ) : (
            <motion.div
              key="3d-view"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.5 }}
              className="absolute inset-0 z-[1] bg-gradient-to-b from-muted-foreground/5 to-muted-foreground/15"
              style={{ perspective: '800px' }}
            >
              <div className="absolute top-0 left-0 right-0 h-[55%] bg-gradient-to-b from-muted/80 to-muted/40 border-b border-border" />
              <div
                className="absolute bottom-0 left-0 right-0 h-[55%]"
                style={{
                  transform: 'rotateX(55deg)',
                  transformOrigin: 'top center',
                }}
              >
                <div className="w-full h-full bg-muted/20" />
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Grid overlay - visible on top of room background */}
        {arSettings.showGrid && (
          <div
            className="absolute inset-0 z-[2] pointer-events-none"
            style={{
              backgroundImage: isCameraMode
                ? 'linear-gradient(rgba(0, 255, 200, 0.2) 1px, transparent 1px), linear-gradient(90deg, rgba(0, 255, 200, 0.2) 1px, transparent 1px)'
                : 'linear-gradient(rgba(100, 100, 100, 0.3) 1px, transparent 1px), linear-gradient(90deg, rgba(100, 100, 100, 0.3) 1px, transparent 1px)',
              backgroundSize: '40px 40px',
            }}
          />
        )}

        {/* AR Scan Lines */}
        {isCameraMode && (
          <ScanOverlay key={scanKey} />
        )}

        {/* Placed Furniture */}
        {currentItems.map((placed) => (
          <FurnitureItem
            key={placed.id}
            placed={placed}
            isSelected={selectedItemId === placed.id}
            isCameraMode={isCameraMode}
            activeTool={activeTool}
            onSelect={handleSelect}
            onDragMove={handleDragMove}
            onDragEnd={handleDragEnd}
            onRotate={handleRotate}
            onScaleUp={handleScaleUp}
            onScaleDown={handleScaleDown}
            onDelete={handleDelete}
          />
        ))}

        {/* Empty state */}
        {currentItems.length === 0 && (
          <div className="absolute inset-0 flex flex-col items-center justify-center z-10">
            <div className={`rounded-2xl p-6 text-center shadow-lg max-w-[280px] ${
              isCameraMode
                ? 'bg-black/60 backdrop-blur-md'
                : 'bg-card/90 backdrop-blur-sm'
            }`}>
              <span className="text-5xl">{isCameraMode ? '📱' : '🪑'}</span>
              <h3 className={`font-bold mt-3 text-lg ${
                isCameraMode ? 'text-white' : 'text-foreground'
              }`}>
                {isCameraMode ? 'AR Room Ready' : 'Empty Room'}
              </h3>
              <p className={`text-sm mt-1 ${
                isCameraMode ? 'text-white/70' : 'text-muted-foreground'
              }`}>
                Tap the + button below to add furniture to this space
              </p>
              <Button
                onClick={() => setShowQuickAdd(true)}
                className="mt-4 bg-primary hover:bg-primary/90"
                size="sm"
              >
                <Plus className="w-4 h-4 mr-1" />
                Add Furniture
              </Button>
            </div>
          </div>
        )}

        {/* Camera Toggle */}
        <div className="absolute top-3 right-3 z-30">
          <Button
            variant="ghost"
            size="icon"
            className={`w-11 h-11 rounded-full shadow-lg ${
              isCameraMode
                ? 'bg-primary/90 text-primary-foreground hover:bg-primary'
                : 'bg-card/80 backdrop-blur-sm hover:bg-card'
            }`}
            onClick={toggleCamera}
          >
            {isCameraMode ? <Camera className="w-5 h-5" /> : <CameraOff className="w-5 h-5" />}
          </Button>
        </div>

        {/* Room Selector */}
        <div className="absolute top-3 left-3 z-30">
          <Button
            variant="ghost"
            size="icon"
            className="w-11 h-11 rounded-full bg-card/80 backdrop-blur-sm shadow-lg hover:bg-card"
            onClick={() => setShowRoomSelector(!showRoomSelector)}
          >
            <Home className="w-5 h-5" />
          </Button>
        </div>

        {/* Grid Toggle */}
        <div className="absolute top-16 left-3 z-30">
          <Button
            variant="ghost"
            size="icon"
            className={`w-9 h-9 rounded-full shadow-lg ${
              arSettings.showGrid
                ? 'bg-primary/80 text-primary-foreground'
                : 'bg-card/80 backdrop-blur-sm'
            }`}
            onClick={toggleGrid}
          >
            <Grid3X3 className="w-4 h-4" />
          </Button>
        </div>

        {/* Floating Add Furniture Button */}
        {currentItems.length > 0 && (
          <div className="absolute bottom-3 right-3 z-30">
            <Button
              className="w-14 h-14 rounded-full shadow-2xl bg-primary hover:bg-primary/90 text-primary-foreground"
              onClick={() => setShowQuickAdd(true)}
            >
              <Plus className="w-6 h-6" />
            </Button>
          </div>
        )}

        {/* Room Selector Panel */}
        <AnimatePresence>
          {showRoomSelector && (
            <motion.div
              initial={{ opacity: 0, x: -20, scale: 0.95 }}
              animate={{ opacity: 1, x: 0, scale: 1 }}
              exit={{ opacity: 0, x: -20, scale: 0.95 }}
              transition={{ duration: 0.2 }}
              className="absolute top-16 left-3 z-40 bg-card/95 backdrop-blur-md rounded-xl border border-border shadow-xl p-3 w-[200px]"
            >
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2">
                Select Room
              </p>
              <div className="space-y-1.5">
                {(Object.keys(roomImages) as RoomType[]).map((type) => {
                  const Icon = roomIcons[type];
                  const isActive = roomType === type;
                  return (
                    <button
                      key={type}
                      onClick={() => switchRoom(type)}
                      className={`flex items-center gap-3 w-full p-2.5 rounded-lg transition-colors ${
                        isActive
                          ? 'bg-primary/15 border border-primary/40'
                          : 'hover:bg-muted/50 border border-transparent'
                      }`}
                    >
                      <div className={`w-9 h-9 rounded-lg bg-gradient-to-br ${roomColorGrads[type]} flex items-center justify-center`}>
                        <Icon className="w-4 h-4 text-white" />
                      </div>
                      <div className="text-left">
                        <span className={`text-sm font-medium ${isActive ? 'text-primary' : 'text-foreground'}`}>
                          {type}
                        </span>
                        {isActive && <p className="text-[10px] text-primary">Active</p>}
                      </div>
                    </button>
                  );
                })}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Click outside to close room selector */}
        {showRoomSelector && (
          <div
            className="absolute inset-0"
            style={{ zIndex: 35 }}
            onClick={() => setShowRoomSelector(false)}
          />
        )}

        {/* Camera mode indicator */}
        {isCameraMode && (
          <div className="absolute bottom-2 left-1/2 -translate-x-1/2 z-20">
            <div className="flex items-center gap-1.5 bg-black/50 backdrop-blur-sm rounded-full px-3 py-1">
              <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse" />
              <span className="text-[10px] text-white font-medium">AR CAMERA</span>
            </div>
          </div>
        )}
      </div>

      {/* Selected Item Controls Panel */}
      {selectedItem && (
        <div className="bg-card border-t border-border px-4 py-3 z-30">
          {/* Header */}
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <div
                className="w-8 h-8 rounded-lg flex items-center justify-center"
                style={{ backgroundColor: `${selectedItem.color}33`, border: `2px solid ${selectedItem.color}` }}
              >
                <span className="text-lg">{selectedItem.emoji}</span>
              </div>
              <div>
                <span className="font-semibold text-sm text-foreground">{selectedItem.name}</span>
                <p className="text-[10px] text-muted-foreground">
                  {selectedItem.rotation}&deg; &middot; {Math.round(selectedItem.scale * 100)}%
                </p>
              </div>
            </div>
            <Button
              variant="ghost"
              size="icon"
              className="w-8 h-8"
              onClick={() => selectItem(null)}
            >
              <X className="w-4 h-4" />
            </Button>
          </div>

          {/* Rotation Control */}
          <div className="mb-3">
            <div className="flex items-center justify-between mb-1">
              <div className="flex items-center gap-1.5">
                <RotateCw className="w-3.5 h-3.5 text-primary" />
                <span className="text-xs font-medium text-foreground">Rotation</span>
              </div>
              <span className="text-xs text-muted-foreground font-mono">{selectedItem.rotation}&deg;</span>
            </div>
            <Slider
              value={[selectedItem.rotation]}
              min={0}
              max={360}
              step={15}
              onValueChange={handleRotationChange}
              className="w-full"
            />
          </div>

          {/* Scale Control */}
          <div className="mb-3">
            <div className="flex items-center justify-between mb-1">
              <div className="flex items-center gap-1.5">
                <Maximize2 className="w-3.5 h-3.5 text-primary" />
                <span className="text-xs font-medium text-foreground">Size</span>
              </div>
              <span className="text-xs text-muted-foreground font-mono">{Math.round(selectedItem.scale * 100)}%</span>
            </div>
            <Slider
              value={[Math.round(selectedItem.scale * 100)]}
              min={30}
              max={250}
              step={5}
              onValueChange={handleScaleChange}
              className="w-full"
            />
          </div>

          {/* Color Control */}
          <div>
            <div className="flex items-center gap-1.5 mb-2">
              <Palette className="w-3.5 h-3.5 text-primary" />
              <span className="text-xs font-medium text-foreground">Color</span>
              <span className="text-[10px] text-muted-foreground ml-auto">tap to change</span>
            </div>
            <div className="flex items-center gap-2 flex-wrap">
              {selectedItemColors.map((color) => (
                <button
                  key={color}
                  className={`w-8 h-8 rounded-full border-2 transition-all active:scale-95 ${
                    selectedItem.color === color
                      ? 'border-primary ring-2 ring-primary/30 scale-110'
                      : 'border-border hover:scale-105'
                  }`}
                  style={{ backgroundColor: color }}
                  onClick={() => handleColorChange(color)}
                />
              ))}
              {/* Custom color input */}
              <div className="relative">
                <input
                  type="color"
                  value={selectedItem.color}
                  onChange={(e) => handleColorChange(e.target.value)}
                  className="w-8 h-8 rounded-full cursor-pointer border-2 border-border overflow-hidden"
                  style={{ padding: 0 }}
                  title="Custom color"
                />
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Bottom Toolbar */}
      <div className="bg-card border-t border-border px-2 py-2 z-30 safe-area-bottom">
        <div className="flex items-center justify-around max-w-md mx-auto">
          {tools.map((tool) => (
            <Button
              key={tool.id}
              variant="ghost"
              size="sm"
              onClick={() => {
                setActiveTool(tool.id);
                if (tool.id === 'delete' && selectedItemId) {
                  handleDelete(selectedItemId);
                }
              }}
              className={`flex flex-col items-center gap-0.5 h-auto py-1.5 px-3 ${
                activeTool === tool.id ? 'text-primary' : 'text-muted-foreground'
              }`}
            >
              <tool.icon className="w-5 h-5" />
              <span className="text-[10px]">{tool.label}</span>
            </Button>
          ))}
          {/* Quick Add button in toolbar */}
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setShowQuickAdd(true)}
            className="flex flex-col items-center gap-0.5 h-auto py-1.5 px-3 text-emerald-600 dark:text-emerald-400"
          >
            <Plus className="w-5 h-5" />
            <span className="text-[10px]">Add</span>
          </Button>
          {/* Save button in toolbar */}
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setShowSaveDialog(true)}
            className="flex flex-col items-center gap-0.5 h-auto py-1.5 px-3 text-amber-600 dark:text-amber-400"
          >
            <Save className="w-5 h-5" />
            <span className="text-[10px]">Save</span>
          </Button>
        </div>
      </div>

      {/* Quick Add Furniture Sheet (Bottom) */}
      <Sheet open={showQuickAdd} onOpenChange={setShowQuickAdd}>
        <SheetContent side="bottom" className="h-[70vh] rounded-t-2xl">
          <SheetHeader className="pb-2">
            <SheetTitle className="flex items-center gap-2">
              <ShoppingBag className="w-5 h-5 text-primary" />
              Add Furniture
            </SheetTitle>
            <SheetDescription>
              Tap any item to add it to your room. You can add multiple items.
            </SheetDescription>
          </SheetHeader>

          {/* Search */}
          <div className="px-1 pb-2">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                value={quickAddSearch}
                onChange={(e) => setQuickAddSearch(e.target.value)}
                placeholder="Search furniture..."
                className="pl-9 h-9 bg-muted/50 text-sm"
              />
            </div>
          </div>

          {/* Category Tabs */}
          <div className="flex gap-1.5 pb-2 overflow-x-auto -mx-1 px-1">
            <Button
              variant={quickAddCategory === 'All' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setQuickAddCategory('All')}
              className="flex-shrink-0 text-xs h-7"
            >
              All
            </Button>
            {categories.map((cat) => (
              <Button
                key={cat}
                variant={quickAddCategory === cat ? 'default' : 'outline'}
                size="sm"
                onClick={() => setQuickAddCategory(cat)}
                className="flex-shrink-0 text-xs h-7"
              >
                {categoryEmojis[cat]} {cat}
              </Button>
            ))}
          </div>

          {/* Items count */}
          <p className="text-xs text-muted-foreground mb-2">
            {quickAddFiltered.length} item{quickAddFiltered.length !== 1 ? 's' : ''} &middot; {currentItems.length} in room
          </p>

          {/* Items Grid */}
          <div className="overflow-y-auto flex-1 -mx-1 px-1 pb-4" style={{ maxHeight: 'calc(70vh - 200px)' }}>
            <div className="grid grid-cols-3 gap-2">
              {quickAddFiltered.map((furniture) => {
                const wasAdded = recentlyAdded.includes(furniture.id);
                return (
                  <button
                    key={furniture.id}
                    onClick={() => handleQuickAdd(furniture)}
                    className={`flex flex-col items-center p-2.5 rounded-xl border transition-all active:scale-95 ${
                      wasAdded
                        ? 'bg-primary/10 border-primary/40'
                        : 'bg-card border-border hover:bg-muted/50'
                    }`}
                  >
                    <span className="text-3xl mb-1">{furniture.emoji}</span>
                    <span className="text-[10px] font-medium text-foreground text-center leading-tight line-clamp-2">
                      {furniture.name}
                    </span>
                    <div className="flex items-center gap-0.5 mt-1">
                      {furniture.colors.slice(0, 3).map((c) => (
                        <div
                          key={c}
                          className="w-2.5 h-2.5 rounded-full border border-border/50"
                          style={{ backgroundColor: c }}
                        />
                      ))}
                    </div>
                    {wasAdded && (
                      <Badge className="mt-1 text-[8px] px-1 py-0 bg-primary/20 text-primary">
                        <Check className="w-2 h-2 mr-0.5" />
                        Added
                      </Badge>
                    )}
                  </button>
                );
              })}
            </div>

            {quickAddFiltered.length === 0 && (
              <div className="flex flex-col items-center justify-center py-8">
                <span className="text-3xl">🔍</span>
                <p className="text-sm text-muted-foreground mt-2">No items found</p>
              </div>
            )}
          </div>
        </SheetContent>
      </Sheet>

      {/* Save Design Dialog */}
      <Dialog open={showSaveDialog} onOpenChange={setShowSaveDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Save Design</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 pt-2">
            <div className="space-y-2">
              <Label>Design Name</Label>
              <Input
                value={designName}
                onChange={(e) => setDesignName(e.target.value)}
                placeholder="My Living Room"
                onKeyDown={(e) => e.key === 'Enter' && handleSave()}
              />
            </div>
            <div className="space-y-2">
              <Label>Room Type</Label>
              <Select value={roomType} onValueChange={(v) => setRoomType(v as RoomType)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Living Room">Living Room</SelectItem>
                  <SelectItem value="Bedroom">Bedroom</SelectItem>
                  <SelectItem value="Kitchen">Kitchen</SelectItem>
                  <SelectItem value="Office">Office</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Preview of items being saved */}
            {currentItems.length > 0 && (
              <div className="bg-muted/30 rounded-lg p-3">
                <p className="text-xs font-medium text-muted-foreground mb-2">
                  Saving {currentItems.length} item{currentItems.length !== 1 ? 's' : ''}:
                </p>
                <div className="flex flex-wrap gap-1.5">
                  {currentItems.map((item) => (
                    <Badge key={item.id} variant="secondary" className="text-[10px]">
                      {item.emoji} {item.name}
                    </Badge>
                  ))}
                </div>
              </div>
            )}

            <Button
              onClick={handleSave}
              className="w-full bg-primary hover:bg-primary/90"
              disabled={currentItems.length === 0}
            >
              <Save className="w-4 h-4 mr-2" />
              Save Design ({currentItems.length} item{currentItems.length !== 1 ? 's' : ''})
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
