'use client';

import { motion } from 'framer-motion';
import { useAppStore, type AppPage } from '@/stores/app-store';
import { Home, Box, Armchair, Bookmark, User } from 'lucide-react';

const navItems: { page: AppPage; icon: typeof Home; label: string }[] = [
  { page: 'dashboard', icon: Home, label: 'Home' },
  { page: 'ar-view', icon: Box, label: 'AR View' },
  { page: 'catalog', icon: Armchair, label: 'Catalog' },
  { page: 'saved', icon: Bookmark, label: 'Saved' },
  { page: 'profile', icon: User, label: 'Profile' },
];

export default function BottomNav() {
  const currentPage = useAppStore((s) => s.currentPage);
  const navigateTo = useAppStore((s) => s.navigateTo);

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 border-t border-border bg-card/95 backdrop-blur-md safe-area-bottom">
      <div className="flex items-center justify-around max-w-lg mx-auto h-16">
        {navItems.map((item) => {
          const isActive = currentPage === item.page;
          return (
            <button
              key={item.page}
              onClick={() => navigateTo(item.page)}
              className="flex flex-col items-center justify-center w-full h-full relative"
            >
              {isActive && (
                <motion.div
                  layoutId="nav-indicator"
                  className="absolute -top-[1px] left-1/2 -translate-x-1/2 w-8 h-0.5 bg-primary rounded-full"
                  transition={{ type: 'spring', stiffness: 350, damping: 30 }}
                />
              )}
              <item.icon
                className={`w-5 h-5 transition-colors ${
                  isActive ? 'text-primary' : 'text-muted-foreground'
                }`}
              />
              <span
                className={`text-[10px] mt-1 transition-colors ${
                  isActive ? 'text-primary font-semibold' : 'text-muted-foreground'
                }`}
              >
                {item.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}
